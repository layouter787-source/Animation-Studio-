// Renders one sample stroke of every brush to PNG. Usage:
//   render_catalog <outdir> [filter-substring] [path/to/stamps.abpack] [--w N --h N]
#include <chrono>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <sys/stat.h>
#include "animbrush/animbrush.hpp"
#include "png_write.hpp"
using namespace ab;

static std::vector<InputSample> makePath(const std::string& kind, int W, int H) {
  std::vector<InputSample> v;
  float speed = 500.f;  // px/s
  auto push = [&](float x, float y, float p, float tx = 0, float ty = 0) {
    InputSample s; s.x = x; s.y = y; s.pressure = p; s.tiltX = tx; s.tiltY = ty;
    if (!v.empty()) { float d = std::hypot(x - v.back().x, y - v.back().y); s.dt = std::max(0.002f, d / speed); } else s.dt = 0.008f;
    v.push_back(s);
  };
  if (kind == "dot") { push(W * 0.5f, H * 0.62f, 0.9f); return v; }
  int n = 160;
  for (int i = 0; i <= n; ++i) {
    float t = i / (float)n;
    float p = 0.15f + 0.85f * std::sin(t * kPi);
    if (kind == "up") push(W * 0.5f + std::sin(t * 5.f) * 6.f, H * 0.92f - t * H * 0.55f, 0.35f + 0.65f * std::sin(t * kPi), 0.2f, 0.1f);
    else if (kind == "line") push(W * 0.1f + t * W * 0.8f, H * 0.5f, 0.2f + 0.8f * std::sin(t * kPi));
    else if (kind == "circle") { float a = t * kTau * 1.02f - kPi * 0.5f; push(W * 0.5f + std::cos(a) * H * 0.3f, H * 0.5f + std::sin(a) * H * 0.3f, p); }
    else if (kind == "arc") { float a = kPi * (1.1f + 0.8f * t); push(W * 0.5f + std::cos(a) * W * 0.38f, H * 0.95f + std::sin(a) * H * 0.75f, p); }
    else if (kind == "zigzag") push(W * 0.1f + t * W * 0.8f, H * 0.5f + ((int)(t * 8) % 2 ? 1 : -1) * H * 0.2f * (std::fmod(t * 8, 1.f) - 0.5f) * 2.f, p);
    else push(W * 0.08f + t * W * 0.84f, H * 0.5f + std::sin(t * kTau * 1.15f) * H * 0.26f, p, 0.3f * std::sin(t * 3), 0.2f);
  }
  return v;
}

static void paintBg(RasterSurface& s, const std::string& bg) {
  int W = s.width(), H = s.height();
  if (bg == "white") s.clear(Color{1, 1, 1, 1});
  else if (bg == "dark") s.clear(Color{0.04f, 0.05f, 0.09f, 1});
  else if (bg == "night") { for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) { float t = y / (float)H; float* p = s.pixel(x, y); p[0] = lerpf(0.02f, 0.08f, t); p[1] = lerpf(0.03f, 0.07f, t); p[2] = lerpf(0.10f, 0.18f, t); p[3] = 1; } }
  else if (bg == "sky") { for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) { float t = y / (float)H; float* p = s.pixel(x, y); p[0] = lerpf(0.45f, 0.82f, t); p[1] = lerpf(0.68f, 0.9f, t); p[2] = lerpf(0.95f, 1.f, t); p[3] = 1; } }
  else if (bg == "paper") { for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) { float n = 0.96f + 0.04f * valueNoise(x * 0.8f, y * 0.8f, 3); float* p = s.pixel(x, y); p[0] = 0.97f * n; p[1] = 0.95f * n; p[2] = 0.90f * n; p[3] = 1; } }
  else if (bg == "fill") {  // pre-painted artwork for erasers: colour bands + line-art + soft blob, on transparent
    for (int y = 0; y < H; ++y) for (int x = 0; x < W; ++x) {
      int band = (int)(x / (W / 4.f)); static const Color cs[4] = {{0.95f, 0.35f, 0.3f, 1}, {0.98f, 0.8f, 0.25f, 1}, {0.3f, 0.7f, 0.95f, 1}, {0.45f, 0.85f, 0.5f, 1}};
      float* p = s.pixel(x, y); Color c = cs[band & 3]; float v = 0.9f + 0.1f * std::sin(y * 0.08f);
      p[0] = c.r * v; p[1] = c.g * v; p[2] = c.b * v; p[3] = 1;
    }
    Dab d; d.color = Color{0.05f, 0.05f, 0.1f, 1}; d.hardness = 1;
    for (int i = 0; i < 6; ++i) { float yy = H * (0.2f + 0.12f * i); dabLine(s, {W * 0.03f, yy}, {W * 0.97f, yy + 14.f * std::sin(i * 1.7f)}, 1.4f, 1.4f, d, 0.2f); }
    Dab soft; soft.color = Color{1, 1, 1, 1}; soft.hardness = 0.f; soft.opacity = 0.9f; soft.radius = 40; soft.x = W * 0.5f; soft.y = H * 0.5f; s.drawDab(soft);
  }
}

int main(int argc, char** argv) {
  std::string out = argc > 1 ? argv[1] : "out";
  std::string filter = argc > 2 ? argv[2] : "";
  std::string pack = argc > 3 ? argv[3] : "";
  int W = 400, H = 200;
  for (int i = 1; i < argc; ++i) { if (!strcmp(argv[i], "--w") && i + 1 < argc) W = atoi(argv[i + 1]); if (!strcmp(argv[i], "--h") && i + 1 < argc) H = atoi(argv[i + 1]); }
  if (filter == "-") filter = "";
  if (pack.empty() || pack[0] == '-') pack = "";
  if (!pack.empty() && !StampBank::instance().loadPack(pack)) fprintf(stderr, "warning: could not load pack %s\n", pack.c_str());
  mkdir(out.c_str(), 0755);
  auto& lib = BrushLibrary::instance();
  { FILE* f = fopen((out + "/catalog.json").c_str(), "w"); if (f) { auto j = lib.catalogJson(); fwrite(j.data(), 1, j.size(), f); fclose(f); } }
  printf("%zu brushes registered, %zu stamps loaded\n", lib.size(), StampBank::instance().size());
  int done = 0;
  for (auto& e : lib.entries()) {
    if (!filter.empty() && e.info.id.find(filter) == std::string::npos && e.info.category != filter) continue;
    auto brush = lib.create(e.info.id);
    if (!brush) continue;
    const BrushInfo& bi = e.info;
    std::string bg = bi.demoBg;
    if (bg.empty()) bg = bi.isEraser ? "fill" : (bi.additive ? "dark" : "white");
    RasterSurface surf(W, H);
    paintBg(surf, bg);
    StrokeParams sp; sp.color = bi.suggestedColor; sp.color2 = bi.suggestedColor2; sp.size = bi.defaultSize; sp.seed = 7; sp.frame = 3; sp.time = 0.4f; sp.opacity = 1.f;
    auto path = makePath(bi.demo, W, H);
    auto t0 = std::chrono::steady_clock::now();
    brush->begin(surf, sp, path[0]);
    for (size_t i = 1; i < path.size(); ++i) brush->move(surf, path[i]);
    float held = 0; while (held < bi.demoHold) { brush->hold(surf, 1.f / 30); held += 1.f / 30; }
    brush->end(surf);
    double ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    auto rgba = (bi.isEraser) ? surf.toRGBA8Checker(8) : surf.toRGBA8(Color{1, 1, 1, 1});
    if (!bi.isEraser && bg != "white") rgba = surf.toRGBA8(Color{0, 0, 0, 1});
    std::string fn = out + "/" + bi.id + ".png";
    pngw::write(fn, W, H, rgba);
    printf("%-34s %-12s %7.1f ms\n", bi.id.c_str(), bi.category.c_str(), ms);
    ++done;
  }
  printf("rendered %d\n", done);
  return 0;
}
