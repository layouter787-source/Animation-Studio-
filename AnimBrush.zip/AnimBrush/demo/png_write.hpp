// Minimal dependency-free PNG writer (stored/uncompressed deflate). For demos & tests only.
#pragma once
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>
namespace pngw {
inline uint32_t crc32(const uint8_t* d, size_t n, uint32_t c = 0xFFFFFFFFu) {
  static uint32_t t[256]; static bool init = false;
  if (!init) { for (uint32_t i = 0; i < 256; ++i) { uint32_t x = i; for (int k = 0; k < 8; ++k) x = x & 1 ? 0xEDB88320u ^ (x >> 1) : x >> 1; t[i] = x; } init = true; }
  for (size_t i = 0; i < n; ++i) c = t[(c ^ d[i]) & 255] ^ (c >> 8);
  return c;
}
inline void be32(std::vector<uint8_t>& v, uint32_t x) { v.push_back(x >> 24); v.push_back(x >> 16); v.push_back(x >> 8); v.push_back(x); }
inline void chunk(FILE* f, const char* type, const std::vector<uint8_t>& data) {
  std::vector<uint8_t> b; be32(b, (uint32_t)data.size()); fwrite(b.data(), 1, 4, f);
  std::vector<uint8_t> td(type, type + 4); td.insert(td.end(), data.begin(), data.end());
  fwrite(td.data(), 1, td.size(), f);
  std::vector<uint8_t> c; be32(c, crc32(td.data(), td.size()) ^ 0xFFFFFFFFu); fwrite(c.data(), 1, 4, f);
}
// rgba: w*h*4 bytes straight RGBA8
inline bool write(const std::string& path, int w, int h, const std::vector<uint8_t>& rgba) {
  FILE* f = fopen(path.c_str(), "wb"); if (!f) return false;
  const uint8_t sig[8] = {137, 80, 78, 71, 13, 10, 26, 10}; fwrite(sig, 1, 8, f);
  std::vector<uint8_t> ihdr; be32(ihdr, w); be32(ihdr, h); ihdr.push_back(8); ihdr.push_back(6); ihdr.push_back(0); ihdr.push_back(0); ihdr.push_back(0);
  chunk(f, "IHDR", ihdr);
  std::vector<uint8_t> raw; raw.reserve((size_t)(w * 4 + 1) * h);
  for (int y = 0; y < h; ++y) { raw.push_back(0); raw.insert(raw.end(), rgba.begin() + (size_t)y * w * 4, rgba.begin() + (size_t)(y + 1) * w * 4); }
  std::vector<uint8_t> z; z.push_back(0x78); z.push_back(0x01);
  size_t pos = 0; uint32_t a = 1, b = 0;
  for (uint8_t v : raw) { a = (a + v) % 65521; b = (b + a) % 65521; }
  while (pos < raw.size()) {
    size_t n = std::min<size_t>(65535, raw.size() - pos); bool last = pos + n >= raw.size();
    z.push_back(last ? 1 : 0); z.push_back(n & 255); z.push_back(n >> 8); z.push_back(~n & 255); z.push_back((~n >> 8) & 255);
    z.insert(z.end(), raw.begin() + pos, raw.begin() + pos + n); pos += n;
  }
  be32(z, (b << 16) | a);
  chunk(f, "IDAT", z); chunk(f, "IEND", {});
  fclose(f); return true;
}
}  // namespace pngw
