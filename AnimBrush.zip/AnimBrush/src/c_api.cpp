#include "animbrush/c_api.h"

#include <cstring>

#include "animbrush/animbrush.hpp"

using namespace ab;

namespace ab { class ISurface; }
struct ab_brush { std::unique_ptr<ab::Brush> b; ab_surface surf; std::unique_ptr<ab::ISurface> cb; };

namespace {
class CbSurface : public ISurface {
 public:
  explicit CbSurface(const ab_surface& s) : s_(s) {}
  int width() const override { return s_.width; }
  int height() const override { return s_.height; }
  void drawDab(const Dab& d) override {
    ab_dab c{};
    c.x = d.x; c.y = d.y; c.radius = d.radius; c.aspect = d.aspect; c.angle = d.angle; c.hardness = d.hardness;
    c.r = d.color.r; c.g = d.color.g; c.b = d.color.b; c.opacity = d.opacity; c.color_alpha = d.colorAlpha;
    c.blend = (int)d.blend; c.lock_alpha = d.lockAlpha; c.mirror_x = d.mirrorX; c.invert_shape = d.invertShape;
    if (d.shape) { c.shape = d.shape->a.data(); c.shape_w = d.shape->w; c.shape_h = d.shape->h; }
    if (d.grain) { c.grain = d.grain->a.data(); c.grain_w = d.grain->w; c.grain_h = d.grain->h; }
    c.grain_depth = d.grainDepth; c.grain_scale = d.grainScale; c.grain_bias = d.grainBias; c.dissolve = d.dissolve; c.seed = d.seed;
    c.ref_r = d.refColor.r; c.ref_g = d.refColor.g; c.ref_b = d.refColor.b; c.tolerance = d.tolerance; c.edge_limit = d.edgeLimit;
    s_.draw_dab(s_.user, &c);
  }
  Color getColor(float x, float y, float r) const override { float o[4] = {0, 0, 0, 0}; s_.get_color(s_.user, x, y, r, o); return {o[0], o[1], o[2], o[3]}; }
  Patch readPatch(IRect r) const override {
    r.x0 = std::max(0, r.x0); r.y0 = std::max(0, r.y0); r.x1 = std::min(s_.width, r.x1); r.y1 = std::min(s_.height, r.y1);
    if (r.empty()) return Patch();
    Patch p(r.x0, r.y0, r.w(), r.h());
    if (s_.read_patch) { s_.read_patch(s_.user, r.x0, r.y0, r.w(), r.h(), p.px.data()); return p; }
    for (int y = r.y0; y < r.y1; ++y) for (int x = r.x0; x < r.x1; ++x) {   /* slow fallback */
      Color c = getColor(x + 0.5f, y + 0.5f, 0.5f); float* q = p.at(x, y); q[0] = c.r * c.a; q[1] = c.g * c.a; q[2] = c.b * c.a; q[3] = c.a; }
    return p;
  }
  void compositePatch(const Patch& p, Blend mode, float opacity) override {
    if (s_.composite_patch) { s_.composite_patch(s_.user, p.x0, p.y0, p.w, p.h, p.px.data(), (int)mode, opacity); return; }
    for (int y = p.y0; y < p.y0 + p.h; ++y) for (int x = p.x0; x < p.x0 + p.w; ++x) {  /* slow fallback: 1px dabs */
      const float* q = p.at(x, y); if (mode != Blend::Smudge && q[3] <= 1e-5f) continue;
      Dab d; d.x = x + 0.5f; d.y = y + 0.5f; d.radius = 0.71f; d.hardness = 1.f; d.blend = mode; d.opacity = opacity;
      if (mode == Blend::Smudge) { d.colorAlpha = q[3]; d.color = q[3] > 1e-5f ? Color{q[0] / q[3], q[1] / q[3], q[2] / q[3], 1} : Color{0, 0, 0, 1}; }
      else { d.opacity = q[3] * opacity; d.color = Color{q[0] / q[3], q[1] / q[3], q[2] / q[3], 1}; }
      drawDab(d);
    }
  }
 private:
  ab_surface s_;
};

std::string g_json;

StrokeParams conv(const ab_stroke_params* p) {
  StrokeParams s;
  s.color = {p->color[0], p->color[1], p->color[2], p->color[3]}; s.color2 = {p->color2[0], p->color2[1], p->color2[2], p->color2[3]};
  s.size = p->size; s.opacity = p->opacity; s.seed = p->seed; s.frame = p->frame; s.time = p->time; s.wind = p->wind; s.intensity = p->intensity; s.lockAlpha = p->lock_alpha != 0;
  return s;
}
InputSample conv(const ab_sample* a) { InputSample i; i.x = a->x; i.y = a->y; i.pressure = a->pressure; i.tiltX = a->tilt_x; i.tiltY = a->tilt_y; i.dt = a->dt; i.rotation = a->rotation; return i; }
}  // namespace

extern "C" {
int ab_init(const char* path) { BrushLibrary::instance(); return path && StampBank::instance().loadPack(path) ? 1 : 0; }
int ab_init_from_memory(const uint8_t* d, uint64_t n) { BrushLibrary::instance(); return StampBank::instance().loadPackFromMemory(d, (size_t)n) ? 1 : 0; }
void ab_add_mask(const char* name, int w, int h, const uint8_t* cov) { Mask m; m.name = name; m.w = w; m.h = h; m.a.assign(cov, cov + (size_t)w * h); StampBank::instance().add(std::move(m)); }
int ab_brush_count(void) { return (int)BrushLibrary::instance().size(); }
const char* ab_brush_id(int i) { auto& e = BrushLibrary::instance().entries(); return i >= 0 && i < (int)e.size() ? e[i].info.id.c_str() : nullptr; }
const char* ab_catalog_json(void) { g_json = BrushLibrary::instance().catalogJson(); return g_json.c_str(); }
ab_brush* ab_brush_create(const char* id) { auto b = BrushLibrary::instance().create(id); if (!b) return nullptr; auto* h = new ab_brush(); h->b = std::move(b); return h; }
void ab_brush_destroy(ab_brush* b) { delete b; }
ab_stroke_params ab_default_params(void) { ab_stroke_params p; std::memset(&p, 0, sizeof p); p.color[3] = 1; p.color2[0] = p.color2[1] = p.color2[2] = p.color2[3] = 1; p.size = 12; p.opacity = 1; p.seed = 1; p.intensity = 1; return p; }
int ab_brush_set_param(ab_brush* b, const char* k, float v) { return b->b->setParam(k, v) ? 1 : 0; }
void ab_stroke_begin(ab_brush* b, const ab_surface* s, const ab_stroke_params* p, const ab_sample* a) {
  b->surf = *s;
  b->cb.reset(new CbSurface(b->surf)); b->b->begin(*b->cb, conv(p), conv(a));
}
void ab_stroke_move(ab_brush* b, const ab_sample* a) { if (b->cb) b->b->move(*b->cb, conv(a)); }
void ab_stroke_hold(ab_brush* b, float dt) { if (b->cb) b->b->hold(*b->cb, dt); }
void ab_stroke_end(ab_brush* b) { if (b->cb) { b->b->end(*b->cb); b->cb.reset(); } }
}
