#include "animbrush/library.hpp"
namespace ab { void registerLightBrushes(BrushLibrary&) {} }
