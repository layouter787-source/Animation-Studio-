#include "animbrush/library.hpp"
namespace ab { void registerStampNatureBrushes(BrushLibrary&) {} }
