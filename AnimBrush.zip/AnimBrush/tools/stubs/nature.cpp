#include "animbrush/library.hpp"
namespace ab { void registerNatureBrushes(BrushLibrary&) {} }
