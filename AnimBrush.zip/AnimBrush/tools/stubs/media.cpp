#include "animbrush/library.hpp"
namespace ab { void registerMediaBrushes(BrushLibrary&) {}
void registerMediaOilZip(BrushLibrary&) {} }
