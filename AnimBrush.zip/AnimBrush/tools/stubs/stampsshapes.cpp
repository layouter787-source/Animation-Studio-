#include "animbrush/library.hpp"
namespace ab { void registerStampShapeBrushes(BrushLibrary&) {} }
