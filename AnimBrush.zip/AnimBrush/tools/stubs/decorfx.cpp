#include "animbrush/library.hpp"
namespace ab { void registerDecorFxBrushes(BrushLibrary&) {} }
