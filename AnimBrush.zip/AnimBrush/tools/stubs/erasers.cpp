#include "animbrush/library.hpp"
namespace ab { void registerEraserBrushes(BrushLibrary&) {} }
