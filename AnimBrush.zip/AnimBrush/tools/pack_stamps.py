#!/usr/bin/env python3
"""Normalise the brush/stamp PNGs of the zip into 8-bit coverage masks (255 = ink)
and write: assets/stamps/<name>.png (grayscale) + assets/stamps.abpack (single file for the C++ StampBank).

usage: pack_stamps.py <extracted_zip_root> <assets_dir>
Polarity rules:
  * PNG with real transparency -> mask = alpha
  * opaque PNG                 -> mask = luminance, inverted when the border is bright (dark shape on white)
  * finally contrast-stretched to 0..255
"""
import glob, os, struct, sys, json
from PIL import Image
import numpy as np

root, out = sys.argv[1], sys.argv[2]
os.makedirs(out + "/stamps", exist_ok=True)
files = sorted(glob.glob(root + "/**/*.png", recursive=True))
entries, report = [], {}
for f in files:
    stem = os.path.splitext(os.path.basename(f))[0]
    name = stem[6:] if stem.startswith("brush_") else stem
    im = Image.open(f).convert("RGBA")
    arr = np.asarray(im).astype(np.float32) / 255.0
    a = arr[..., 3]
    if a.min() < 0.98:
        m = a.copy(); mode = "alpha"
        # semi-transparent images whose colour is also informative: keep alpha only
    else:
        lum = 0.2126 * arr[..., 0] + 0.7152 * arr[..., 1] + 0.0722 * arr[..., 2]
        border = np.concatenate([lum[0, :], lum[-1, :], lum[:, 0], lum[:, -1]]).mean()
        if border > 0.5:
            lum = 1.0 - lum; mode = "luma-inverted"
        else:
            mode = "luma"
        m = lum
    lo, hi = float(m.min()), float(m.max())
    if hi - lo > 1e-4:
        m = (m - lo) / (hi - lo)
    m8 = np.clip(m * 255 + 0.5, 0, 255).astype(np.uint8)
    Image.fromarray(m8, "L").save(f"{out}/stamps/{name}.png")
    h, w = m8.shape
    ys, xs = np.nonzero(m8 > 40)
    bbox = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())] if len(xs) else [0, 0, 0, 0]
    report[name] = dict(w=int(w), h=int(h), mode=mode, mean=round(float(m.mean()), 3), bbox=bbox,
                        category=os.path.basename(os.path.dirname(os.path.dirname(f))))
    entries.append((name, w, h, m8.tobytes()))

with open(out + "/stamps.abpack", "wb") as fp:
    fp.write(b"ABPK" + struct.pack("<II", 1, len(entries)))
    for name, w, h, data in entries:
        fp.write(name.encode()[:47].ljust(48, b"\0") + struct.pack("<HH", w, h) + data)
json.dump(report, open(out + "/stamps_report.json", "w"), indent=1)
print(len(entries), "masks ->", out)
