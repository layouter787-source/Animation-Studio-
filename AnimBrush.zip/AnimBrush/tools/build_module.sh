#!/bin/bash
# Incremental per-module build so parallel developers don't break each other.
# usage: tools/build_module.sh <module>   (media|nature|light|stampsnature|stampsshapes|erasers|decorfx)
# Output: build_<module>/render_catalog
set -e
cd "$(dirname "$0")/.."
KEY=$1
[ -z "$KEY" ] && { echo "usage: $0 <module>"; exit 1; }
OUT=build_$KEY; mkdir -p $OUT/obj
SRCS="$(ls src/*.cpp) src/brushes/stamps.cpp demo/render_catalog.cpp"
for k in media nature light stampsnature stampsshapes erasers decorfx; do
  if [ "$k" = "$KEY" ]; then SRCS="$SRCS $(ls src/brushes/${k}*.cpp)"; else SRCS="$SRCS tools/stubs/$k.cpp"; fi
done
OBJS=""
pids=()
for s in $SRCS; do
  o=$OUT/obj/$(echo $s | tr '/' '_').o
  OBJS="$OBJS $o"
  if [ ! -f "$o" ] || [ "$s" -nt "$o" ] || [ -n "$(find include -newer $o -name '*.hpp' 2>/dev/null)" ] || [ demo/png_write.hpp -nt "$o" ]; then
    g++ -std=c++17 -O2 -Wall -Wextra -Wno-unused-parameter -Iinclude -Idemo -c $s -o $o &
    pids+=($!)
  fi
done
fail=0; for p in "${pids[@]}"; do wait $p || fail=1; done
[ $fail = 1 ] && { echo "BUILD FAILED"; exit 1; }
g++ $OBJS -o $OUT/render_catalog
echo "built $OUT/render_catalog"
