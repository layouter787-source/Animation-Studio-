# Integração no seu app

1. **Surface**: implemente `ab::ISurface` (5 métodos): `drawDab`, `getColor` (para smudge), `readPatch`, `compositePatch`, `width/height`.
   - `drawDab(Dab)`: elipse de semi-eixos `radius*aspect` (ao longo de `angle`) × `radius`; cobertura = máscara `shape` esticada nesse retângulo (ou ponta redonda com `hardness`); × `opacity`; × grão `grain` (papel, ancorado na tela); `dissolve` descarta pixels por hash. `Blend` define a composição (ver `surface.hpp`; `RasterSurface::drawDab` é a referência exata).
   - Em GPU: um quad por dab com fragment shader equivalente; os blends especiais (`EraseSimilar`, `EraseDark`, `Soften`...) precisam ler o destino (copie a região do dab antes).
2. **Texturas**: carregue `stamps.abpack` (ou decodifique os PNGs de `assets/stamps/` no Android e chame `StampBank::add`).
3. **Entrada**: converta eventos do `MotionEvent` em `InputSample` (pressure, tilt, `dt` em segundos). Chame `hold()` num timer quando a caneta está parada.
4. **Animação**: passe `StrokeParams.frame`/`time`/`wind`. Para efeitos que devem "ferver" (relâmpago, fogo) mude o `frame` a cada quadro; para traço estático mantenha constante.
5. **Kotlin/JNI**: use `c_api.h` (`ab_surface` com callbacks). 
6. **UI**: `catalogJson()` → lista de pincéis, categorias, sliders (`params`). Ajuste com `Brush::setParam(key, v)`.
7. Layers de luz (`info.additive`): pinte em layer com modo de mistura *Add/Screen* sobre fundo escuro.
8. Pincéis com buffer de traço (marcador, aquarela) fazem a composição final em `compositePatch`; faça-a atômica por traço para o undo.
