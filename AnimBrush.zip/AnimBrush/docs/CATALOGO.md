# Catálogo de pincéis e borrachas — AnimBrush

Total: **500** pincéis/borrachas em 35 categorias. Gerado automaticamente de `catalog.json`.

Cada entrada: id · nome · tamanho padrão (raio px) · flags (A=animado por frame/tempo, L=luz aditiva, E=borracha) · parâmetros de UI · como funciona na vida real e como foi modelado.


## lapis (11)

- **`lapis.9h`** — Lápis 9H (duro) · r=3 · params: Textura do papel
  Na vida real: grafite muito duro: risco fino, claro e quase uniforme, mal enche os vales do papel. Modelo: ponta pequena e dura, opacidade baixa, dente do papel quase integral.

- **`lapis.hb`** — Lápis HB · r=4 · params: Textura do papel
  Na vida real: grafite médio: risco equilibrado; a pressão aprofunda o grafite nos vales do papel. Modelo: pressão controla opacidade e o limiar do dente do papel (grainBias).

- **`lapis.2b`** — Lápis 2B · r=5 · params: Textura do papel
  Na vida real: grafite macio: risco escuro, aveludado, mancha fácil. Modelo: ponta mais larga e macia; menos dependência do papel.

- **`lapis.6b`** — Lápis 6B · r=7 · params: Textura do papel
  Na vida real: grafite muito macio: preto profundo, largo, quase pastoso. Modelo: ponta larga, opacidade alta, pouco dente.

- **`lapis.porta-minas`** — Lapiseira · r=2
  Na vida real: mina fina de diâmetro constante; traço uniforme e nítido, só a pressão muda o tom. Modelo: raio constante, opacidade pela pressão, dente leve.

- **`lapis.sombreado-inclinado`** — Lápis de sombrear (inclinado) · r=6 · params: Textura do papel
  Na vida real: deitar o lápis usa a lateral do grafite: faixa larga e macia, mais clara quanto mais deitado. Modelo: inclinação da caneta (tilt) alonga a pegada (aspect) e orienta pela direção da inclinação.

- **`lapis.colorido`** — Lápis de cor · r=5 · params: Textura do papel
  Na vida real: cera + pigmento: camadas sobrepostas ficam mais saturadas, o papel aparece nos vales, polir com pressão fecha o grão. Modelo: opacidade baixa acumulativa, grão de trama, pequena variação de matiz/valor por marca.

- **`lapis.carvao`** — Lápis carvão · r=5
  Na vida real: carvão prensado em madeira: preto fosco, grão áspero, falha ao ser arrastado leve. Modelo: grão grosso, jitter de posição e pequenos buracos.

- **`lapis.esboco`** — Lápis de esboço · r=4
  Na vida real: traços rápidos saem leves e soltos, devagar escurecem. Modelo: opacidade cai com a velocidade (speed1), leve tremor.

- **`zip.pencil_graphite`** — Grafite texturizado · r=12 · textura: `pencil_graphite`
  Na vida real: ponta de grafite larga com granulação própria (a textura da ponta é irregular, nunca uma bolinha lisa). Modelo: carimbo de grafite girado ao acaso para não repetir o padrão, pressão modula opacidade.

- **`zip.pencil_charcoal`** — Carvão em cunha · r=12 · textura: `pencil_charcoal`
  Na vida real: pedaço de carvão quebrado: ponta triangular facetada, deixa uma faixa de largura que depende de como se segura. Modelo: ponta triangular girada perpendicular à direção do traço, fibras do papel.


## carvao-giz (16)

- **`carvao.vinha`** — Carvão de vinha · r=14 · params: Textura do papel
  Na vida real: galho de videira carbonizado: leve, quebradiço, deixa poeira e partículas soltas; é fácil de apagar e esfumar. Modelo: grão grosso, buracos aleatórios (dissolve) e deriva de posição.

- **`carvao.comprimido`** — Carvão comprimido · r=12
  Na vida real: carvão compactado com aglutinante: preto denso e profundo, poucos vazios. Modelo: alta opacidade, grão fraco.

- **`giz.bastao`** — Giz de bastão · r=12
  Na vida real: giz calcário: pega só nos picos do papel, deixa risco opaco e seco. Modelo: pegada achatada perpendicular ao traço, grão forte.

- **`pastel.macio`** — Pastel seco macio · r=16 · params: Textura do papel
  Na vida real: pigmento quase puro: veludo opaco que se esfuma com o dedo e mistura com a camada de baixo. Modelo: pequena parcela de smudge mistura com o que já existe; grão grosso.

- **`pastel.duro`** — Pastel seco duro (Conté) · r=10
  Na vida real: barra dura de pastel: ponta de quina permite linhas nítidas e hachuras; cobre menos. Modelo: pegada achatada com ângulo fixo (quina da barra).

- **`pastel.oleoso`** — Pastel oleoso · r=14
  Na vida real: cera + óleo: nunca seca, arrasta e empasta quando se passa por cima. Modelo: smudge alto com memória longa; cobertura quase total; grão de trama.

- **`giz.cera`** — Giz de cera · r=9
  Na vida real: cera sobre papel rugoso: cobre os picos, deixa pontinhos brancos nos vales; pressão fecha o grão. Modelo: grão do papel com bias por pressão.

- **`giz.conte`** — Conté sanguínea · r=11
  Na vida real: bastão de conté marrom-avermelhado: tom quente, risco firme e granulado. Modelo: pegada achatada girada; grão médio.

- **`giz.lousa`** — Giz de lousa · r=8
  Na vida real: giz branco no quadro-negro: traço opaco, sem fim de tinta; falha e deixa poeira. Modelo: grão grosso e buracos; contraste forte sobre fundo escuro.

- **`zip.chalk01`** — Giz nuvem · r=20 · textura: `chalk01`
  Na vida real: giz macio que deixa uma mancha irregular, de contorno felpudo. Modelo: carimbo felpudo girado ao acaso, baixa opacidade acumulativa.

- **`zip.chalk02`** — Giz pétalas · r=22 · textura: `chalk02`
  Na vida real: giz que cai em pó formando manchas de lóbulos. Modelo: carimbo lobulado com espalhamento (scatter) e giro aleatório.

- **`zip.chalk_charcoal`** — Carvão em pó · r=22 · textura: `chalk_charcoal`
  Na vida real: pó de carvão esfregado: nuvem manchada, escura no centro. Modelo: carimbo irregular escuro, giro aleatório, dissolve para pó.

- **`zip.chalk_crayon`** — Crayon texturizado · r=14 · textura: `chalk_crayon`
  Na vida real: crayon pressionado de lado: pegada lobulada com cera manchada. Modelo: carimbo texturizado girado com a direção, grão do papel.

- **`zip.chalk_hard`** — Giz retangular duro · r=14 · textura: `chalk_hard`
  Na vida real: giz de ponta retangular (de quadro-negro): lasca reta que deixa faixa larga áspera. Modelo: ponta retangular que mantém a quina alinhada à direção.

- **`zip.chalk_pastel_hard`** — Pastel retangular duro · r=14 · textura: `chalk_pastel_hard`
  Na vida real: barra de pastel duro usada pela face: faixa retangular com tom que varia. Modelo: ponta retangular orientada e grão médio.

- **`zip.chalk_pastel_soft`** — Pastel macio redondo · r=18 · textura: `chalk_pastel_soft`
  Na vida real: disco de pastel macio: pigmento granulado e translúcido, esfuma. Modelo: carimbo circular granulado, giro aleatório, opacidade baixa que acumula.


## tinta (22)

- **`tinta.tecnica`** — Caneta técnica (nanquim) · r=2
  Na vida real: ponta tubular: traço de largura exata, sem variação, sem pressão. Modelo: raio constante, hardness 1.

- **`tinta.rapidografo`** — Rapidógrafo · r=2.5
  Na vida real: tubo com agulha: linha perfeitamente uniforme, ligeiramente mais escura ao parar. Modelo: raio constante, leve acúmulo de tinta com a lentidão.

- **`tinta.gpen`** — G-pen (mangá) · r=5
  Na vida real: pena de metal flexível: pressão abre as pontas e engrossa; afina nas pontas do traço, bem nítida. Modelo: raio pelo pressure (0.08→1) com leve afinamento pela velocidade; hardness 1.

- **`tinta.maru`** — Maru-pen · r=3
  Na vida real: pena redonda de detalhe: linha mais fina e constante que a G-pen, ainda com pequena variação. Modelo: faixa de raio estreita pela pressão.

- **`tinta.mapping`** — Mapping pen · r=2
  Na vida real: pena de mapa, muito fina e rígida: traço sutilmente nervoso. Modelo: raio mínimo + pequeno tremor.

- **`tinta.fonte`** — Caneta-tinteiro · r=4
  Na vida real: a tinta acumula quando a mão pára e afina quando corre; a ponta de ouro dá uma leve variação. Modelo: raio e opacidade dependem da velocidade (mais lento = mais largo e escuro).

- **`tinta.esferografica`** — Esferográfica · r=2.2
  Na vida real: esfera rolante: tinta falha em momentos, escurece com pressão e deixa um fio contínuo. Modelo: opacidade pela pressão, falhas aleatórias (dissolve), grão de papel leve.

- **`tinta.gel`** — Caneta de gel · r=3
  Na vida real: gel opaco e brilhante: cobre bem, traço uniforme e levemente espesso. Modelo: raio constante, bordas ligeiramente macias.

- **`tinta.feltro`** — Caneta de feltro · r=4
  Na vida real: ponta de feltro: traço macio, translúcido onde sobrepõe-se; não escurece dentro do mesmo traço. Modelo: buildUp desligado (buffer de traço) + borda suave.

- **`tinta.pincel-caneta`** — Pincel-caneta (brush pen) · r=6
  Na vida real: ponta flexível: engrossa com a pressão e afina em velocidade com cauda fina. Modelo: raio pela pressão (0.05→1.1) e redução forte pela velocidade.

- **`tinta.caligrafia`** — Caligrafia (pena chata) · r=6
  Na vida real: pena de ponta chata fixa a 45°: o traço é fino na direção do corte e grosso na perpendicular. Modelo: pegada elíptica com ângulo fixo 45° (aspect 4): a espessura vem só da geometria.

- **`tinta.cana`** — Cana (reed pen) · r=5
  Na vida real: caniço cortado: linha áspera, borda irregular, absorção do papel. Modelo: elipse inclinada com fibras de papel e tremor.

- **`tinta.pena-tinteiro`** — Pena de molhar (dip pen) · r=4 · params: Capacidade de tinta
  Na vida real: mergulha-se a pena: a tinta acaba pouco a pouco e o traço desbota até ser preciso molhar de novo. Modelo: opacidade e largura decrescem com a distância percorrida (Length); parâmetro 'capacidade'.

- **`tinta.pena-quill`** — Pena de ganso (quill) · r=5
  Na vida real: pena de ave cortada: engrossa pela pressão e pela inclinação, aveludada nos extremos. Modelo: aspect pelo tilt, raio pela pressão e velocidade.

- **`tinta.lavagem`** — Lavagem de nanquim · r=22
  Na vida real: nanquim diluído: lavis cinza translúcido, camadas somam-se aos poucos. Modelo: dab macio de baixa opacidade com grão grosso, acumulativo.

- **`zip.pen01`** — Caneta redonda macia · r=5 · textura: `pen01`
  Na vida real: caneta de ponta redonda com borda ligeiramente suave. Modelo: ponta redonda do pacote, raio pela pressão.

- **`zip.pen02`** — Caneta redonda dura · r=4 · textura: `pen02`
  Na vida real: caneta dura: borda definida, sem variação de opacidade. Modelo: ponta de borda dura, raio constante com pequena reação à pressão.

- **`zip.pen02_old`** — Caneta gasta (serrilhada) · r=4 · textura: `pen02_old`
  Na vida real: caneta velha cujo contorno é irregular: o traço sai serrilhado e rústico. Modelo: ponta de borda irregular e giro aleatório para quebrar a regularidade.

- **`zip.pen_bleed`** — Caneta que borra · r=7 · textura: `pen_bleed`
  Na vida real: tinta que escorre nas fibras do papel: o contorno vaza com bordas manchadas e tom mais denso no centro. Modelo: ponta manchada de borda irregular, opacidade alta e leve deriva; espaçamento maior para manter a mancha.

- **`zip.pen_fade`** — Marca-texto fosco · r=8 · textura: `pen_fade`
  Na vida real: caneta que desbota: marca translúcida cinzenta que se acumula por sobreposição. Modelo: ponta cinza translúcida, opacidade baixa, acumulativa.

- **`tinta.sumie`** — Sumi-ê (pincel de nanquim) · r=14 · params: Carga de tinta, Abertura das cerdas, Secura
  Na vida real: pincel de pelo largo e pontudo: o centro fica molhado e escuro, as bordas secas deixam fios brancos (hakuboku); tinta vaza um pouco no papel. Modelo: 30 cerdas de baixa opacidade acumulando no centro, secura por velocidade, halo de bleed.

- **`tinta.pincel-seco`** — Pincel seco de nanquim · r=14 · params: Carga de tinta, Abertura das cerdas, Secura
  Na vida real: pincel quase sem tinta arrastado rápido: apenas filamentos pretos entrecortados (feibai). Modelo: alta secura e depleção rápida.


## marcador (7)

- **`marcador.chanfrado`** — Marcador chanfrado · r=12
  Na vida real: ponta chata cortada em bisel: traço largo na direção do corte, fino na outra; cor translúcida que escurece ao repassar. Modelo: elipse achatada com ângulo fixo, buffer de traço (sem escurecer no mesmo traço) e mistura Multiply.

- **`marcador.texto`** — Marca-texto · r=14
  Na vida real: tinta fluorescente translúcida: realça sem esconder o que está embaixo; ponta chata larga. Modelo: Multiply, ponta retangular larga, opacidade ~55%.

- **`marcador.alcool`** — Marcador a álcool (Copic) · r=12
  Na vida real: tinta de álcool: bordas levemente molhadas que se fundem; sobrepor faz camadas mais escuras e começa com um ponto mais carregado. Modelo: buildUp desligado, borda suave, escurecimento no início do traço (opacidade pelo Stroke).

- **`marcador.pincel`** — Marcador pincel · r=10
  Na vida real: ponta flexível de pincel: engrossa com a pressão; traço opaco-translúcido. Modelo: raio pela pressão, buffer de traço.

- **`marcador.fino`** — Fineliner · r=2
  Na vida real: caneta de ponta fina de feltro: linha precisa que não escurece ao cruzar o próprio traço. Modelo: raio constante, buffer de traço.

- **`marcador.tinta-opaca`** — Marcador de tinta opaca · r=9
  Na vida real: marcador de tinta à base de pigmento: cobre totalmente, borda nítida, fosco. Modelo: opacidade 1, borda dura, grão de tela leve.

- **`marcador.giz-liquido`** — Marcador de giz líquido · r=10
  Na vida real: tinta de giz líquido: opaca, seca fosca com leve textura, borda arredondada. Modelo: buffer de traço com grão grosso discreto.


## aerografo (17)

- **`aerografo.suave`** — Aerógrafo suave · r=30 · params: Fluxo de tinta
  Na vida real: jato de ar com tinta fina: nuvem gaussiana; parado, a cor se acumula até saturar. Modelo: hardness 0, opacidade baixa por marca, dabs por segundo mantêm o acúmulo com a mão parada.

- **`aerografo.duro`** — Aerógrafo de borda definida · r=18
  Na vida real: bico próximo da superfície: pontos pequenos de borda quase nítida. Modelo: hardness 0.6, opacidade moderada.

- **`aerografo.granulado`** — Aerógrafo granulado · r=28
  Na vida real: tinta salpicada em gotículas minúsculas: aparência sandy/grão, mais visível em tom claro. Modelo: nuvem macia com 'dissolve' alto: pixels isolados em vez de névoa lisa.

- **`aerografo.estencil`** — Spray pontilhado (stipple) · r=24
  Na vida real: pontilhado de bico fino: pontos redondos distribuídos aleatoriamente com densidade gaussiana. Modelo: muitas marcas pequenas espalhadas (count/scatter) em disco.

- **`aerografo.respingo`** — Respingo de aerógrafo (spatter) · r=26
  Na vida real: gotas grandes e pequenas lançadas ao acaso: pingos maiores perto do centro e satélites miúdos. Modelo: dabs de raio muito variado espalhados; cada marca com opacidade quase total.

- **`aerografo.poeira`** — Poeira (speckle) · r=30
  Na vida real: grãos finíssimos como poeira mineral. Modelo: espalhamento muito denso de marcas minúsculas.

- **`aerografo.glitter`** — Spray de glitter · r=24
  Na vida real: partículas de brilho metálico que refletem cores diferentes ao acaso. Modelo: marcas pequenas duras com variação forte de matiz/valor.

- **`zip.air01`** — Aerógrafo ponto fino · r=12 · textura: `air01`
  Na vida real: bico de detalhe: nuvem pequena que acompanha a pressão no tamanho (retoque de realces). Modelo: carimbo radial 'air01' pequeno, pressão → raio.

- **`zip.air02`** — Aerógrafo suave médio · r=20 · textura: `air02`
  Na vida real: pulverização aberta: transição longa entre cor e papel. Modelo: carimbo 'air02', pressão → opacidade (não o tamanho).

- **`zip.air03`** — Aerógrafo por velocidade · r=22 · textura: `air03`
  Na vida real: mão rápida deposita menos tinta: o jato fica fraco ao varrer e forte ao parar. Modelo: carimbo 'air03', opacidade cai com a velocidade (speed1).

- **`zip.air04`** — Aerógrafo cheio · r=20 · textura: `air04`
  Na vida real: jato com núcleo mais concentrado e bordas curtas. Modelo: carimbo 'air04' + variação aleatória de raio/posição.

- **`zip.air05`** — Aerógrafo sobre papel · r=22 · textura: `air05`
  Na vida real: o jato cobre o papel rugoso: pontinhos brancos permanecem nos vales. Modelo: carimbo 'air05' com grão de papel.

- **`zip.air06`** — Aerógrafo opaco (chapado) · r=26 · textura: `air06`
  Na vida real: tinta cobrindo quase totalmente com leve esfumado na borda; para fundos. Modelo: carimbo 'air06' largo e opaco, esticado ao longo do movimento.

- **`zip.air_particle`** — Partículas finas · r=24 · textura: `air_particle`
  Na vida real: areia soprada: grãos minúsculos espalhados com direção aleatória. Modelo: carimbo de partículas girado ao acaso com deriva.

- **`zip.air_particle2`** — Partículas grossas · r=24 · textura: `air_particle2`
  Na vida real: pedrinhas e sementes salpicadas. Modelo: carimbo de pontos maiores, giro aleatório, escala variável.

- **`zip.gauze01`** — Carimbo de gaze · r=22 · textura: `gauze01`
  Na vida real: tecido de gaze pressionado com tinta: deixa trama de fios e furos. Modelo: carimbo de trama girado ao acaso, buffer de traço + Multiply para que a trama não sature.

- **`aerografo.lata-spray`** — Spray (lata) com escorrimento · r=28 · params: Escorrimento
  Na vida real: tinta spray: névoa de gotas, mais densa no centro; se a lata fica parada a tinta acumula e escorre em fios. Modelo: disco de gotas com densidade uniforme; segurando parado (hold) nascem escorrimentos com gravidade e gota na ponta.


## mistura (9)

- **`mistura.dedo`** — Dedo (esfumar) · r=20
  Na vida real: o dedo arrasta a tinta úmida: cor sai do ponto de partida e deixa rastro que vai se esgotando. Modelo: Smudge 0.95 com memória longa.

- **`mistura.macio`** — Esfumaço macio · r=18
  Na vida real: esfuminho de papel: mistura curta e delicada, preserva a estrutura. Modelo: Smudge baixo-médio com memória curta, borda macia.

- **`mistura.umido`** — Mistura úmida · r=22
  Na vida real: tinta molhada recolhe a cor do que encontra e mistura com a cor do pincel. Modelo: Smudge 0.7 + cor do pincel residual (colore o rastro).

- **`mistura.desfocar`** — Desfocar · r=20
  Na vida real: borrar sem arrastar: tudo se suaviza em vez de se deslocar. Modelo: Blend::Soften (média local 5x5) sob a marca.

- **`mistura.misturador`** — Misturador de cor · r=24
  Na vida real: espátula de mistura de cores: mistura os pigmentos de duas áreas sem pintar nada novo. Modelo: Smudge puro com raio de amostragem grande.

- **`mistura.pastel`** — Esfumar pastel · r=20
  Na vida real: dedo sobre pastel: arrasta o pigmento, grão do papel se mantém. Modelo: Smudge com grão do papel.

- **`mistura.carvao`** — Esfumar carvão · r=22
  Na vida real: a palma arrasta o carvão em faixas direcionais, deixando um véu cinza. Modelo: Smudge com pegada alongada na direção do traço.

- **`mistura.liquify`** — Arrastar (liquify) · r=24
  Na vida real: empurra a imagem como borracha de barro: desloca sem desbotar. Modelo: Smudge 1.0 com memória quase infinita e pegada firme.

- **`mistura.seco`** — Mistura a seco · r=20
  Na vida real: pincel seco sobre pigmento seco: só raspa e mistura nos picos do papel. Modelo: Smudge com grão do papel como máscara.


## aquarela (13)

- **`aquarela.umido-umido`** — Aquarela úmido sobre úmido · r=26 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: papel molhado: o pigmento se espalha para além do traço com bordas suaves, cores se fundem; o pigmento ainda acumula nas margens. Modelo: buffer de traço (sem acúmulo interno), sangramento por desfoque no fim do traço, escurecimento de borda, granulação do papel.

- **`aquarela.umido-seco`** — Aquarela úmido sobre seco · r=24 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: papel seco: bordas nítidas, o pigmento se junta na borda quando seca (anel mais escuro). Modelo: sem sangramento; forte escurecimento de borda; granulação média.

- **`aquarela.pincel-seco`** — Aquarela pincel seco · r=20 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: pincel quase sem água arrasta pigmento só nos picos do papel: traço quebrado com muitas falhas brancas, mais quebrado quanto mais rápido. Modelo: limiar do grão do papel cresce com a velocidade (secura gravada no buffer).

- **`aquarela.lavis`** — Lavis plano (wash) · r=48 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: pincel largo carregado de água: camada translúcida uniforme, quase sem granulação. Modelo: grande, baixa saturação, borda leve.

- **`aquarela.veladura`** — Veladura (glaze) · r=34 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: camada finíssima de cor por cima da seca: a cor de baixo transparece e as duas se misturam opticamente. Modelo: Multiply com pigmento baixo: sobrepor aprofunda a cor sem tapar.

- **`aquarela.sal`** — Aquarela com sal · r=30 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: grãos de sal absorvem a água e pigmento: sobram manchas claras em estrela. Modelo: máscara celular (worley) esvazia o pigmento em blotches.

- **`aquarela.floracao`** — Floração (backrun) · r=28 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: água nova numa área quase seca empurra o pigmento: cria uma 'couve-flor' clara com anel escuro. Modelo: bolhas aleatórias ao longo do traço esvaziadas no miolo e com anel de pigmento.

- **`aquarela.guache`** — Guache · r=22 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: tinta opaca mate: cobre o que está embaixo, seca sem brilho, ligeiramente giz. Modelo: Normal blend opaco com granulação mínima.

- **`aquarela.tinta-na-agua`** — Tinta difundindo na água · r=22 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: gota de tinta em água parada: expande em nuvem, volutas e perde densidade. Modelo: grande sangramento com baixíssima definição de borda.

- **`aquarela.granulado`** — Pigmento granulado · r=26 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda
  Na vida real: pigmentos pesados (ultramarino, siena) assentam nos vales do papel: aspecto sujo-granulado. Modelo: granulação máxima + escurecimento nos vales.

- **`zip.water_bleed`** — Mancha que sangra · r=24 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda · textura: `water_bleed`
  Na vida real: gota de aquarela solta numa área úmida: mancha de contorno orgânico com tons de profundidade. Modelo: carimbo de mancha irregular girado ao acaso + sangramento no fim do traço.

- **`zip.water_point`** — Pingo de pigmento · r=20 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda · textura: `water_point`
  Na vida real: toque do pincel carregado: mancha densa de pigmento, escura no centro e borda definida. Modelo: carimbo de gota densa com borda marcada, giro aleatório.

- **`zip.water_real`** — Aquarela real (rasgada) · r=26 · params: Pigmento, Umidade (sangrar), Granulação, Escurecer borda · textura: `water_real`
  Na vida real: toque largo de aquarela com bordas rasgadas, respingos e partes de pigmento seco. Modelo: carimbo natural girado ao acaso, secura parcial e floração.


## oleo-acrilica (14)

- **`oleo.chata`** — Óleo – pincel chato · r=24 · params: Carga de tinta, Abertura das cerdas, Mistura com a tela
  Na vida real: cerdas de porco em linha: arrasta tinta em fita larga com sulcos paralelos; mistura com a tinta úmida por baixo e vai descarregando. Modelo: 18 cerdas independentes (carga, tom e largura próprios), depositam com Smudge para misturar com a tela úmida, impasto com luz/sombra nos sulcos.

- **`oleo.redondo`** — Óleo – pincel redondo · r=14 · params: Carga de tinta, Abertura das cerdas, Mistura com a tela
  Na vida real: pincel redondo termina em ponta: fino com pouca pressão, abre ao pressionar; ótimo para detalhes e contornos. Modelo: cerdas em disco, o raio de abertura cresce com a pressão.

- **`oleo.filbert`** — Óleo – pincel filbert · r=22 · params: Carga de tinta, Abertura das cerdas, Mistura com a tela
  Na vida real: filbert tem ponta oval: traços com bordas arredondadas e mistura macia nas pontas. Modelo: bristles dispostos em arco, as pontas do arco ficam recuadas.

- **`oleo.leque`** — Óleo – pincel leque (esfumar) · r=28 · params: Carga de tinta, Abertura das cerdas, Mistura com a tela
  Na vida real: pincel em leque: cerdas finas e abertas, serve para esfumar e unir tons, deixa texturas de pelos finos. Modelo: cerdas em arco aberto, quase só pickup (mistura), pouca tinta depositada.

- **`oleo.seco`** — Óleo – pincel seco · r=24 · params: Carga de tinta, Abertura das cerdas, Secura, Mistura com a tela
  Na vida real: pincel quase sem tinta: só os picos da tela recebem pigmento e cada cerda deixa seu risco; acaba rápido. Modelo: cerdas com secura por velocidade, carga esgota depressa.

- **`oleo.impasto`** — Óleo – impasto grosso · r=26 · params: Carga de tinta, Abertura das cerdas, Mistura com a tela
  Na vida real: tinta em camada grossa: o pincel deixa relevo; a luz bate nas cristas e as sombras ficam nos sulcos. Modelo: 32 cerdas em linha com highlight (Overlay) e sombra nos dois lados de cada sulco.

- **`oleo.espatula`** — Espátula (palette knife) · r=24 · params: Carga de tinta, Abertura das cerdas, Mistura com a tela
  Na vida real: lâmina de aço: arrasta a tinta em placas lisas, deixa crista nas bordas e raspa o que estava embaixo. Modelo: 56 'cerdas' juntas formam uma lâmina lisa com forte pickup e crista (impasto).

- **`acrilica.chata`** — Acrílica – pincel chato · r=22 · params: Carga de tinta, Abertura das cerdas
  Na vida real: acrílica seca rápido: cobre opaca, traços definidos que não se misturam; cerdas deixam leves sulcos. Modelo: como o chato a óleo mas sem pickup e com bordas duras.

- **`oleo.esfumado-granulado`** — Scumble (velatura seca) · r=26 · params: Carga de tinta, Abertura das cerdas, Secura
  Na vida real: camada seca e irregular passada por cima: deixa a cor de baixo aparecer em poros. Modelo: cerdas em disco, jitter por movimento e secura por velocidade.

- **`oleo.esponja`** — Esponja / pontilhado · r=20 · params: Carga de tinta, Abertura das cerdas
  Na vida real: esponja natural: carimba furinhos irregulares; cada toque tem poros diferentes. Modelo: 30 pontos por toque (dots), tamanho aleatório e variação de tom.

- **`oleo.tela-trama`** — Pincel sobre tela texturizada · r=22 · params: Carga de tinta, Abertura das cerdas, Mistura com a tela
  Na vida real: tela de linho: a tinta só adere nos fios, a trama aparece nas áreas pouco carregadas. Modelo: grão de trama na deposição; mistura moderada.

- **`zip.oil_line_hard`** — Óleo: cerdas duras (linhas) · r=20 · textura: `oil_line_hard`
  Na vida real: pincel de cerdas duras (porco) arrasta a tinta espessa deixando sulcos paralelos nitidos na direcao do golpe. Modelo: mascara de linhas onduladas girada para seguir a direcao do traco, borda dura, pressao muda tamanho e carga, mistura leve com a tinta do suporte (smudge).

- **`zip.oil_line_soft`** — Óleo: cerdas macias (mistura) · r=22 · textura: `oil_line_soft`
  Na vida real: pincel macio (marta/sintetico) puxa tinta umida e a mistura, deixando veios suaves e degrades de cor. Modelo: mascara de linhas suaves seguindo a direcao, com forte captura de cor do suporte e memoria longa do balde de tinta.

- **`zip.oil_rough`** — Óleo: pinceladas ásperas (dab) · r=18 · textura: `oil_rough`
  Na vida real: toques curtos de pincel carregado (pontilhado impressionista) deixam manchas de tinta macias de formatos irregulares e variacao de tom. Modelo: carimbo de manchas soltas com rotacao e escala aleatorias, espacamento largo, leve variacao de matiz/valor por toque.


## arvores (16)

- **`arvores.carvalho`** — Árvore folhosa (carvalho) · r=12 · [A] · params: Ramificação, Folhagem
  Na vida real: o tronco afina com a altura, se divide em galhos que obedecem à regra de Leonardo (a soma das áreas dos galhos filhos = área do galho-pai), cada galho curva-se para a luz (fototropismo) e a copa é feita de massas de folhas iluminadas por cima. Modelo: o traço é o tronco (casca com fissuras e flare de raiz); a copa cresce por recursão de 4-6 níveis com raios r_filho = r/√k, curvatura para cima e ruído; as pontas recebem lóbulos de folhagem pintados em 3 passes (sombra, corpo, luz) com folhas de carimbo por cima; o vento (StrokeParams.wind/time) balança os galhos.

- **`arvores.cerejeira`** — Cerejeira (sakura) · r=12 · [A] · params: Ramificação, Folhagem
  Na vida real: a sakura floresce antes das folhas; os galhos são escuros e tortuosos, cobertos de nuvens de flores rosa-claro que caem como chuva de pétalas. Modelo: crescimento de galhos escuros mais tortuosos; copa de lóbulos com mistura rosa/branco em vez de verde; pétalas soltas espalhadas abaixo da copa.

- **`arvores.outono`** — Árvore de outono · r=12 · [A] · params: Ramificação, Folhagem
  Na vida real: no outono a clorofila some e os carotenoides/antocianinas aparecem; a copa vai do verde (interior/baixo) ao amarelo, laranja e vermelho nas pontas mais expostas. Modelo: mesmo motor de crescimento do carvalho; cor de cada lóbulo varia com a altura e ruído em gradiente verde→amarelo→laranja→vermelho; folhas de bordo em carimbo.

- **`arvores.betula`** — Bétula (vidoeiro) · r=12 · [A] · params: Ramificação, Folhagem
  Na vida real: casca branca com marcas horizontais pretas (lenticelas), galhos finos e ascendentes, ramos finais pendentes e folhagem clara e esparsa. Modelo: tronco branco com listras negras horizontais, ângulo de ramificação estreito e fototropismo forte, folhagem pequena rala e raminhos pendentes com folhinhas.

- **`arvores.pinheiro`** — Pinheiro / conífera · r=12 · [A] · params: Andares, Neve
  Na vida real: crescimento monopodial (um líder central) com galhos em verticilos; os de baixo são longos e pendem sob o peso, os de cima curtos, dando a silhueta de cone; as agulhas formam saias densas escuras por baixo. Modelo: tronco-líder; andares sobrepostos de baixo para cima, largura ∝ (1-t)^0.85, borda inferior irregular (dentes) com agulhas pendentes, luz à esquerda e sombra sob cada andar; opcional neve.

- **`arvores.palmeira`** — Palmeira · r=12 · [A] · params: Tamanho da copa
  Na vida real: tronco único sem galhos, curvo e anelado pelas cicatrizes das folhas; no topo, uma coroa de frondes pinadas que se arqueiam e pendem, com folíolos pendurados dos dois lados; cocos sob a coroa. Modelo: tronco com anéis; 11 frondes em arco de Bézier (as de trás desenhadas primeiro), folíolos pares cujo comprimento segue sin(πt) e pendem para baixo, balanço pelo vento.

- **`arvores.salgueiro`** — Salgueiro-chorão · r=12 · [A] · params: Quantidade de fios
  Na vida real: ramos finos e longos pendem verticalmente da copa quase até o chão, com folhas estreitas, balançando ao vento. Modelo: galhos principais com forte curvatura para baixo; dezenas de fios pendentes (curvas senoidais) com folhinhas alternadas e deslocamento pelo vento crescente com a queda.

- **`arvores.seca`** — Árvore seca (inverno) · r=12 · [A] · params: Ramificação, Neve
  Na vida real: sem folhas, vê-se a arquitetura: ramificação fina e fractal, galhos que afinam até gravetos, com neve acumulada em cima. Modelo: recursão profunda (até 6 níveis) com ruído alto, sem folhagem; opção de neve nas pontas.

- **`arvores.bonsai`** — Bonsai · r=10 · [A] · params: Tamanho das nuvens
  Na vida real: tronco torcido com arame, galhos horizontais e copa em 'nuvens' achatadas, a forma é desenhada pelo cultivador. Modelo: tronco ondulado grosso, 3-4 galhos laterais e almofadas de folhagem achatadas em 3 camadas com pontilhado nas bordas.

- **`arvores.acacia`** — Acácia (guarda-chuva) · r=12 · [A] · params: Largura da copa
  Na vida real: a acácia da savana tem tronco curto que se abre em galhos quase horizontais e uma copa plana como guarda-chuva (os herbívoros comem a parte baixa). Modelo: poucos galhos de ângulo largo e copa em 3 camadas elípticas achatadas, luz no topo.

- **`arvores.baoba`** — Baobá · r=8 · [A] · params: Folhagem
  Na vida real: tronco enorme em forma de garrafa (armazena água), casca lisa cinza-parda com sulcos, poucos galhos grossos e curtos no topo. Modelo: perfil de raio alargado na base e afinando a 62%, sulcos verticais acentuados, 5 galhos curtos e grossos com copa pequena.

- **`arvores.cacto`** — Cacto saguaro · r=10 · [A]
  Na vida real: coluna carnuda com costelas verticais (que se expandem ao absorver água), espinhos pálidos nos vértices, braços que saem na horizontal e sobem. Modelo: cilindro com costelas escuras, luz à esquerda, espinhos nas costelas, braços em curva (horizontal → vertical) e flor rosa no topo.

- **`arvores.bambu`** — Bambu · r=8 · [A] · params: Folhas
  Na vida real: colmos retos e ocos divididos em entrenós por nós salientes; ramos finos nascem nos nós superiores com folhas lanceoladas. Modelo: colmo com nós (anel escuro + brilho) a cada ~4 larguras com espaçamento irregular, ramos alternados e folhas lanceoladas em leque.

- **`arvores.mangue`** — Mangue · r=9 · [A] · params: Copa
  Na vida real: raízes-escora arqueiam a partir do tronco e mergulham na lama, sustentando a árvore na maré; copa densa e escura. Modelo: raízes em arcos de Bézier saindo de várias alturas para o nível do solo, tronco fino, copa de lóbulos escuros.

- **`arvores.floresta`** — Floresta (fileira de árvores) · r=9 · params: Densidade
  Na vida real: em uma floresta distante as árvores se sobrepõem e a névoa (perspectiva atmosférica) clareia e azula as mais distantes. Modelo: ao longo do traço nascem árvores (pinheiros e redondas) com profundidade aleatória; as distantes são menores e misturadas ao azul-névoa; ordenadas do fundo para a frente.

- **`arvores.folhas-caindo`** — Folhas caindo · r=14 · [A] · params: Densidade
  Na vida real: uma folha solta oscila como um pêndulo ao cair (arrasto + sustentação), girando devagar; as de outono têm cores do verde ao vermelho. Modelo: a cada passo do traço nasce uma folha (máscara de folha/ginkgo/bordo) deslocada para baixo com rotação aleatória, tombamento (achatamento pelo cos), sombra suave e flutuação lateral pelo vento.


## plantas (11)

- **`plantas.grama`** — Grama / campo · r=9 · [A] · params: Densidade
  Na vida real: cada folha de capim nasce do solo, e uma lamina estreita que curva sob o proprio peso e o vento; tufos tem alturas diferentes, mais escuros na base e mais claros nas pontas.

- **`plantas.trigo`** — Campo de trigo · r=9 · [A] · params: Densidade
  Na vida real: colmo fino e reto com espiga de graos em escamas alternadas no topo, dourado e inclinado pelo vento.

- **`plantas.junco`** — Juncos e taboas · r=9 · [A] · params: Densidade
  Na vida real: haste alta e lisa nas margens de lagos; a taboa tem uma espiga marrom cilindrica no topo e folhas em fita.

- **`plantas.flores-campo`** — Campo de flores · r=10 · [A] · params: Densidade
  Na vida real: flores silvestres de cores variadas sobre hastes verdes finas, cada uma voltada para a luz.

- **`plantas.arbusto`** — Arbusto / sebe · r=16 · [A] · params: Densidade
  Na vida real: massa densa de folhas em tufos; a luz bate em cima e à esquerda, e o interior fica escuro.

- **`plantas.musgo`** — Musgo · r=8 · [A] · params: Densidade
  Na vida real: almofadas densas de plantinhas minúsculas que cobrem pedra e tronco, verde-vivo na luz e escuro nas frestas.

- **`plantas.cogumelos`** — Cogumelos · r=9 · [A]
  Na vida real: haste clara e chapéu arredondado com manchas, lamelas escuras embaixo.

- **`plantas.algas`** — Algas / kelp · r=10 · [A]
  Na vida real: o kelp e preso ao fundo por uma raiz e flutua para cima por bolsas de ar, oscilando com a corrente.

- **`plantas.samambaia`** — Samambaia · r=10 · [A]
  Na vida real: fronde arqueada em que cada pinas se divide em pinulas menores, auto-similar, enrolada na ponta jovem. Modelo: fractal recursivo - eixo curvo seguindo o traço, pares de folíolos decrescentes e sub-folíolos.

- **`plantas.hera`** — Hera trepadeira · r=8 · [A] · params: Densidade
  Na vida real: caule fino que se agarra à superfície, folhas alternadas em pares com ângulos variados e gavinhas enroladas. Modelo: o traço vira o caule; folhas lobadas alternam dos lados com tamanho variável; gavinhas em espiral nos nós.

- **`plantas.coral`** — Coral ramificado · r=6
  Na vida real: coral-galho cresce por bifurcações sucessivas de pólipos calcários, formando um leque irregular. Modelo: ramificação dicotômica recursiva com espessura decrescente e pontas arredondadas.


## terreno (7)

- **`terreno.montanhas`** — Cadeia de montanhas · r=14 · params: Aspereza
  Na vida real: picos são fractais (a mesma rugosidade em várias escalas); o lado iluminado é claro, o oposto escuro, picos altos têm neve, e cadeias distantes são mais claras e azuladas (perspectiva atmosférica). Modelo: crista por deslocamento do ponto médio (3 camadas de profundidade) a partir do traço, preenchimento com faces luz/sombra e neve acima de um limiar.

- **`terreno.rochas`** — Rochas facetadas · r=14
  Na vida real: rocha fraturada tem faces planas; a face voltada para a luz é clara, a lateral média e o topo/base escuros; fendas escuras entre faces.

- **`terreno.pedregulhos`** — Pedregulhos / seixos · r=5
  Na vida real: seixos de rio são lisos e arredondados, com luz suave e sombra projetada.

- **`terreno.dunas`** — Dunas de areia · r=14
  Na vida real: o vento forma dunas com barlavento suave e sotavento íngreme (crista afiada), cobertas por marcas de ondulação. Modelo: cristas senoidais assimétricas ao longo do traço, face de sombra escura e linhas de ondulação.

- **`terreno.terra-rachada`** — Terra rachada · r=10
  Na vida real: lama que seca encolhe e racha em polígonos (junções em T de ~120°). Modelo: bordas de células de Worley ao longo do traço, desenhadas escuras e com lasca clara ao lado.

- **`terreno.estratos`** — Estratos de rocha · r=12
  Na vida real: camadas de sedimento empilhadas em faixas de cores e espessuras diferentes, às vezes inclinadas.

- **`terreno.rio`** — Rio / córrego · r=10
  Na vida real: leito sinuoso, mais estreito nas curvas internas, com margens escuras e brilho na superfície.


## agua (7)

- **`agua.ondas-mar`** — Ondas do mar · r=12 · [A] · params: Densidade
  Na vida real: onda e a soma de harmônicas; a crista quebra em espuma branca e cada onda tem um lado de sombra; as filas seguem a linha da costa.

- **`agua.ondulacoes`** — Ondulações · r=12 · [A]
  Na vida real: uma pedra na água gera anéis concêntricos que se expandem e enfraquecem, vistos em perspectiva como elipses.

- **`agua.bolhas`** — Bolhas · r=10 · [A] · params: Densidade
  Na vida real: bolha de sabão/água é esfera quase transparente com borda mais visível e dois reflexos (janela) em lados opostos, tons iridescentes.

- **`agua.espuma`** — Espuma · r=10 · [A] · params: Densidade
  Na vida real: espuma e um aglomerado de bolhas brancas de tamanhos variados, com sombras finas entre elas.

- **`agua.respingo`** — Respingo (coroa) · r=10 · [A]
  Na vida real: uma gota/pedra faz uma coroa de filetes que lançam gotículas em arco (balística).

- **`agua.cachoeira`** — Cachoeira · r=12 · [A] · params: Densidade
  Na vida real: queda d'água tem fios verticais brancos que se esticam com a velocidade e termina numa névoa de espuma.

- **`agua.pingos`** — Pingos escorrendo · r=5 · [A]
  Na vida real: gota escorre por gravidade deixando um rastro fino e termina numa bolha mais grossa.


## clima (9)

- **`clima.chuva`** — Chuva · r=8 · [A] · params: Densidade
  Na vida real: gotas caem rápido e o olho vê riscos inclinados pelo vento; as de longe são curtas e fracas, as de perto longas e nítidas.

- **`clima.neve`** — Nevasca / flocos · r=9 · [A] · params: Densidade
  Na vida real: flocos caem devagar, balançando, e as de perto parecem grandes e borradas, as de longe pontinhos nítidos.

- **`clima.granizo`** — Granizo · r=8 · [A]
  Na vida real: pedras de gelo opacas, esféricas, que quicam; riscos curtos e brancos com ponto de brilho.

- **`clima.cumulo`** — Nuvem cúmulo · r=16 · params: Densidade
  Na vida real: cúmulo é feito de bolhas de ar quente subindo: topo branco iluminado, base achatada e cinza-azulada.

- **`clima.tempestade`** — Nuvem de tempestade · r=16 · params: Densidade
  Na vida real: cumulonimbo é imenso, base escura quase preta e topo em bigorna; a luz mal passa.

- **`clima.estrato`** — Nuvens estrato · r=16 · params: Densidade
  Na vida real: estrato são camadas largas e achatadas, uniformes, que cobrem o céu como um lençol.

- **`clima.cirros`** — Cirros (nuvens de gelo) · r=10
  Na vida real: cirros são cristais de gelo em altitude, fiapos finos e longos esticados pelo vento. Modelo: dezenas de fios translúcidos que seguem o traço e se curvam para a ponta.

- **`clima.geada`** — Geada / cristais de gelo · r=10
  Na vida real: cristal de gelo cresce por difusão com simetria hexagonal, ramos a 60° que se bifurcam (dendrito). Modelo: crescimento recursivo em 6 direções a partir do ponto final, ramos laterais a 60°, tamanho decrescente.

- **`clima.sincelos`** — Sincelos · r=8 · [A]
  Na vida real: água escorre e congela formando cones de gelo mais grossos no topo, translúcidos, com brilho vertical.


## pelos (6)

- **`pelos.pelo-curto`** — Pelo curto · r=9 · params: Densidade
  Na vida real: pelagem é feita de fios finos que seguem a direção do crescimento, com subpelo escuro e pontas claras.

- **`pelos.cabelo`** — Cabelo (mechas) · r=10 · params: Densidade
  Na vida real: mechas fluem juntas, com raiz no couro, pontas que se soltam e uma faixa de brilho que acompanha a curvatura.

- **`pelos.cilios`** — Cílios · r=5
  Na vida real: cílios nascem da pálpebra em leque, curvam-se para cima e afinam na ponta; os do canto externo são mais longos.

- **`pelos.escamas`** — Escamas · r=8
  Na vida real: escamas de peixe/réptil são arcos sobrepostos em fileiras alternadas, mais claros na borda livre.

- **`pelos.pena`** — Pena · r=8
  Na vida real: pena tem um eixo (raque) e barbas paralelas que se prendem por barbulas, com a ponta afilada e o lado curto/longo assimétrico. Modelo: o traço é a raque; centenas de barbas finas inclinadas para a ponta, com variação de cor e fendas.

- **`pelos.dente-de-leao`** — Sementes de dente-de-leão · r=8
  Na vida real: cada semente tem um pára-quedas (pappus) de filamentos radiais e é soprada pelo vento.


## luz (18)

- **`luz.brilho`** — Pincel de Luz (brilho suave) · r=12 · [L] · params: Brilho, Halo
  Na vida real: uma fonte de luz não é uma linha clara: a intensidade cai com o quadrado da distância, o centro satura para branco e só a cauda guarda a cor. Modelo: núcleo branco-quente + corpo colorido + halo largo com queda 1/(1+k·d²) em Blend::Add; o núcleo clareia conforme o brilho aumenta.

- **`luz.neon`** — Tubo de Neon · r=8 · [AL] · params: Brilho, Halo, Tremor (flicker)
  Na vida real: tubo de gás ionizado: miolo quase branco, cor saturada em volta, halo que ilumina a parede, cintilação leve da rede elétrica e pontas arredondadas com eletrodos. Modelo: espessura constante (pouca variação por pressão), tremor por frame/tempo, eletrodo opaco na ponta final.

- **`luz.laser`** — Feixe Laser · r=10 · [L] · params: Brilho, Halo, Faíscas no fim
  Na vida real: laser: feixe finíssimo e coerente, quase sem halo; no ponto de impacto a luz espalha e solta fagulhas. Modelo: linha muito fina com núcleo branco, halo estreito; ao soltar, mancha de impacto + faíscas radiais.

- **`luz.longa-exposicao`** — Light Painting (longa exposição) · r=9 · [L] · params: Brilho, Halo, Tremida da mão
  Na vida real: foto de longa exposição: onde a lanterna se move devagar o sensor acumula mais luz; a mão treme e a cor oscila. Modelo: ganho ∝ 1/velocidade, deslocamento suave por ruído (tremida), gradiente cor→cor2 ao longo do traço.

- **`luz.contorno-neon`** — Contorno Luminoso Oco · r=16 · [L] · params: Brilho, Largura do vão
  Na vida real: letreiro de duas linhas de neon que desenham o contorno de uma faixa, com o miolo vazio. Modelo: duas linhas luminosas deslocadas pela normal do traço, largura do vão pela pressão.

- **`luz.raios-de-sol`** — Raios de Sol (god rays) · r=14 · [L] · params: Ângulo dos raios (°), Comprimento, Poeira no ar
  Na vida real: luz atravessando folhas/janelas forma colunas visíveis (dispersão de Tyndall em poeira), com bordas irregulares e partículas flutuando. Modelo: feixes paralelos num ângulo fixo, abertos/fechados por ruído ao longo do traço (a oclusão), fade longitudinal e poeira cintilante.

- **`luz.reflexo-lente`** — Reflexo de Lente (lens flare) · r=12 · [L] · params: Reflexos internos, Estrela de difração, Anamórfico (faixa)
  Na vida real: luz forte em uma objetiva gera estrela de difração (lâminas do diafragma) e reflexos internos espelhados em torno do centro óptico, hexagonais e coloridos. Modelo: estrela de 6 pontas, bloom, e fantasmas alinhados no eixo fonte→centro da tela com formas hexagonais/discos e cores deslocadas.

- **`luz.estrelinha`** — Estrelinha Faiscante · r=9 · [AL] · params: Densidade, Gravidade, Alcance
  Na vida real: partículas de ferro incandescente voam em balística, esfriam de branco a laranja e algumas explodem em mini-estrelas. Modelo: partículas com gravidade, rampa de temperatura ao longo da vida, bifurcação em mini-estrela; hold() mantém a emissão.

- **`luz.vagalumes`** — Vaga-lumes · r=14 · [AL] · params: Espaçamento, Velocidade do pulso
  Na vida real: vaga-lumes piscam com fase própria: longos instantes apagados e pulsos curtos amarelo-esverdeados. Modelo: pontos aleatórios em volta do traço com brilho = pulso senoidal por frame com fase individual.

- **`luz.bokeh`** — Bokeh · r=18 · [L] · params: Lâminas do diafragma (0=redondo), Variação de cor, Densidade
  Na vida real: pontos de luz fora de foco viram discos com a forma do diafragma (polígonos), mais brilhantes na borda, de tamanho conforme a distância. Modelo: discos/polígonos com anel brilhante, tamanho com distribuição enviesada (muitos pequenos, poucos grandes), variação de cor.

- **`luz.cintilar`** — Brilho Estrela (glint) · r=11 · [AL] · params: Pontas (4/8), Espaçamento
  Na vida real: brilho de diamante/sol na água: cruz de difração de 4 ou 8 pontas que pisca. Modelo: bloom + dois traços perpendiculares finíssimos (e diagonais opcionais) com tamanho pulsando por frame.

- **`luz.aura`** — Aura de Energia · r=12 · [AL] · params: Altura das chamas, Turbulência
  Na vida real: aura estilo anime: línguas de energia que sobem do corpo, mais claras junto a ele e coloridas nas pontas, ondulando. Modelo: chamas verticais de 3 camadas por ruído que evolui com o frame, inclinadas pelo vento.

- **`luz.fita-magica`** — Fita Mágica Trançada · r=9 · [L] · params: Comprimento da onda, Amplitude
  Na vida real: rastros de magia formam fitas entrelaçadas; o fio da frente é mais brilhante que o de trás, com faíscas soltas. Modelo: 3 fios senoidais defasados em 120°, brilho/espessura pela profundidade (cos), brilho extra e centelhas.

- **`luz.plasma`** — Globo de Plasma · r=14 · [AL] · params: Filamentos, Alcance
  Na vida real: globo de plasma: filamentos violeta saem do eletrodo central e procuram o vidro, mudando a cada instante. Modelo: núcleo branco + filamentos gerados por caminhada tortuosa curta em genBolt, re-sorteados a cada emissão.

- **`luz.holograma`** — Holograma · r=12 · [AL] · params: Espaço das linhas, Glitch
  Na vida real: projeção holográfica: linhas de varredura, aberração cromática e falhas horizontais que mudam a cada quadro. Modelo: linhas finas com intensidade aleatória por frame, franjas vermelha/azul deslocadas, deslocamento de bandas (glitch).

- **`luz.lampiao`** — Luz de Vela/Lampião · r=16 · [AL] · params: Temperatura (K), Tremor da chama
  Na vida real: luz de chama é laranja a ~1900-2400 K e vai ficando amarelo-branca no centro; a poça de luz respira. Modelo: camadas concêntricas coloridas por corpo negro (blackbody) — externa mais vermelha, núcleo mais branco —, com tremor.

- **`luz.holofote`** — Holofote (cone de luz) · r=10 · [L] · params: Abertura (°), Poeira
  Na vida real: feixe de holofote/farol: cone cuja intensidade cai da lâmpada para fora e que revela poeira no ar. Modelo: leque de faixas finas com perfil de cos² e ruído; poeira dentro do cone; direção = início→fim do traço.

- **`luz.fibra-optica`** — Fibra Óptica · r=12 · [L] · params: Número de fibras
  Na vida real: feixe de fibras ópticas: fios finos de cores diferentes serpenteiam em paralelo e brilham apenas nas pontas. Modelo: N fios com deslocamento senoidal próprio, cor por matiz, luz extra nas pontas.


## raios (13)

- **`raios.relampago`** — Raio · r=12 · [AL] · params: Ramificação, Tortuosidade, Brilho, Tamanho do trecho (px)
  Na vida real: um raio é um canal de plasma que avança em degraus (líder escalonado) escolhendo caminhos tortuosos, bifurca, e os ramos são mais finos e fracos; o canal principal é branco e cercado de halo azulado. Modelo: cada trecho do traço vira um canal por caminhada com 'memória' de curva, bifurcações com probabilidade decrescente, núcleo branco + bainha + halo, estreitando nos ramos; re-sorteado a cada frame.

- **`raios.ramificado`** — Raio Ramificado (árvore) · r=12 · [AL] · params: Ramificação, Tortuosidade, Brilho, Tamanho do trecho (px)
  Na vida real: raios intra-nuvem e de nuvem a solo mostram muitas ramificações finas em forma de árvore invertida. Modelo: mesmo modelo de canal mas com altíssima chance de bifurcação, profundidade 3 e ramos mais tortuosos.

- **`raios.solo`** — Raio de Descarga ao Solo · r=12 · [AL] · params: Ramificação, Tortuosidade, Brilho, Tamanho do trecho (px)
  Na vida real: no raio nuvem-solo o líder desce em direção ao chão ramificando para baixo e o contato produz um clarão intenso (descarga de retorno) com salpico de ar ionizado. Modelo: canal com viés para baixo, ramos descendentes, flash largo e estrela horizontal no ponto de impacto.

- **`raios.corrente`** — Raio Encadeado (chain lightning) · r=11 · [AL] · params: Ramificação, Tortuosidade, Brilho, Tamanho do trecho (px)
  Na vida real: o arco elétrico salta de um alvo condutor ao próximo mais próximo. Modelo: trechos longos curtos conectados por canais fortes e esferas brilhantes em cada nó com faíscas.

- **`raios.tempestade`** — Tempestade (raio + clarão do céu) · r=14 · [AL] · params: Ramificação, Tortuosidade, Brilho, Tamanho do trecho (px)
  Na vida real: durante o raio a nuvem inteira se acende e o céu fica roxo-azulado por um instante. Modelo: canal principal mais clarão amplo e difuso sobre cada trecho.

- **`raios.tesla`** — Arco Tesla (rastro elétrico) · r=10 · [AL] · params: Arcos por passo, Alcance do arco
  Na vida real: uma bobina de Tesla lança arcos finos e violáceos do eletrodo para qualquer ponto condutor próximo, sem cessar. Modelo: a cada passo, arcos curtos e muito tortuosos ligam a ponta da caneta a pontos recentes do rastro.

- **`raios.estalo`** — Estalos Elétricos · r=9 · [AL] · params: Densidade
  Na vida real: eletricidade estática faz minifaíscas brancas saltarem ao acaso, curtas e muito tortuosas. Modelo: mini-canais de 1 a 3 raios do pincel, dispersos aleatoriamente em volta do traço, com pontinhos de impacto.

- **`raios.clarao-nuvem`** — Relâmpago de Folha (clarão na nuvem) · r=30 · [AL] · params: Intensidade do clarão
  Na vida real: no relâmpago de folha só se vê um brilho difuso e irregular dentro da nuvem; o canal fica escondido. Modelo: manchas grandes de ruído (nuvem) acesas por lobos independentes e variação por frame; raro canal fraco por trás.

- **`raios.bola`** — Raio Globular · r=12 · [AL] · params: Arcos em espiral
  Na vida real: relato de esfera luminosa de plasma flutuando, com filamentos em espiral e uma esteira de ar ionizado. Modelo: esfera com núcleo branco, arcos espiralados em volta, tentáculos curtos e rastro fraco.

- **`raios.feixe-energia`** — Feixe de Energia (kamehameha) · r=14 · [AL] · params: Turbulência da borda, Anéis de pulso, Faíscas
  Na vida real: raio de energia de anime: núcleo branco, casca turbulenta colorida, anéis de pulso que correm pelo feixe, faíscas e cabeça brilhante. Modelo: três camadas com largura modulada por ruído que anda com o frame, anéis perpendiculares a cada passo fixo, faíscas saltando da casca, orbe na ponta.

- **`raios.rachadura`** — Rachadura de Energia · r=9 · [L] · params: Ramificação, Brilho interno
  Na vida real: um objeto que racha mostrando energia interna: fissura escura e irregular com veio incandescente e bifurcações em ângulos agudos. Modelo: canais em passos largos, desenhados primeiro como fenda escura (Normal) depois veio quente + halo (Add).

- **`raios.solda`** — Arco de Solda · r=9 · [AL] · params: Faíscas
  Na vida real: arco de solda: ponto ofuscante branco-azulado, cordão derretido laranja atrás e chuva de faíscas caindo com gravidade. Modelo: ponto com flicker, cordão em rampa de calor, faíscas balísticas; hold() solta mais faíscas.

- **`raios.descarga`** — Descarga Elétrica (explosão) · r=9 · [AL] · params: Número de raios, Alcance
  Na vida real: uma descarga que se espalha em todas as direções a partir de um ponto de contato. Modelo: raios radiais bifurcados saindo do fim do traço + núcleo brilhante.


## fogo (12)

- **`fogo.chama`** — Chama realista · r=14 · [AL] · params: Intensidade, Altura/escala
  Na vida real: o fogo e gas incandescente: o ar quente sobe (empuxo), a turbulencia cria linguas que tremem, e a cor depende da temperatura (branco no nucleo, laranja, vermelho, some em fumaca). Modelo: linguas de chama independentes (20 elipses aditivas empilhadas) com flutuacao por ruido de gradiente que muda a cada frame, empuxo, inclinacao pelo vento e cor por rampa de corpo negro (branco-amarelo-laranja-vermelho-escuro).

- **`fogo.chama-azul`** — Chama azul · r=13 · [AL] · params: Intensidade, Altura/escala
  Na vida real: chama de gas/alta temperatura queima mais limpa e azulada (combustao completa). Modelo: linguas de chama independentes (20 elipses aditivas empilhadas) com flutuacao por ruido de gradiente que muda a cada frame, empuxo, inclinacao pelo vento e cor por rampa de corpo negro (branco-amarelo-laranja-vermelho-escuro).

- **`fogo.chama-verde`** — Chama verde magica · r=13 · [AL] · params: Intensidade, Altura/escala
  Na vida real: sais de cobre colorem a chama de verde; aqui vira fogo magico. Modelo: linguas de chama independentes (20 elipses aditivas empilhadas) com flutuacao por ruido de gradiente que muda a cada frame, empuxo, inclinacao pelo vento e cor por rampa de corpo negro (branco-amarelo-laranja-vermelho-escuro).

- **`fogo.chama-roxa`** — Chama roxa magica · r=13 · [AL] · params: Intensidade, Altura/escala
  Na vida real: chama alquimica/fogo fatuo; mesma fisica do fogo com rampa roxa. Modelo: linguas de chama independentes (20 elipses aditivas empilhadas) com flutuacao por ruido de gradiente que muda a cada frame, empuxo, inclinacao pelo vento e cor por rampa de corpo negro (branco-amarelo-laranja-vermelho-escuro).

- **`fogo.vela`** — Chama de vela · r=10 · [AL] · params: Intensidade, Altura/escala
  Na vida real: a chama de vela e laminar e quase imovel: gota alongada, base azul perto do pavio (combustao completa), miolo escuro de cera vaporizada, ponta amarela. Modelo: gota aditiva em camadas (halo quente, corpo amarelo, miolo transparente, base azul) na posicao inicial; so oscila levemente com o frame.

- **`fogo.rastro`** — Rastro de fogo · r=11 · [AL] · params: Intensidade, Altura/escala
  Na vida real: um objeto em chamas deixa para tras fogo que sobe e se dissipa; quanto mais velho o ponto, mais baixo e frio. Modelo: linguas pequenas com altura proporcional a velocidade, sempre empurradas contra o sentido do movimento, com brasas.

- **`fogo.tocha`** — Tocha · r=12 · [AL] · params: Intensidade, Altura/escala
  Na vida real: uma tocha tem um cabo escuro e uma massa de chama larga e ondulante com fagulhas e fumaca no topo. Modelo: o traco vira o cabo (madeira); no fim do gesto surge a chama grande com varias linguas, fagulhas e halo de luz quente.

- **`fogo.fogueira`** — Fogueira · r=12 · [AL] · params: Intensidade, Altura/escala
  Na vida real: toras apoiadas em cruz, brasas vermelhas no leito e chamas que sobem da massa de brasa; a luz alaranjada ilumina o chao ao redor. Modelo: toras escuras (elipses com veio) ao longo do traco, leito de brasas pulsante (aditivo) e linguas de fogo mais altas no centro.

- **`fogo.brasas`** — Brasas e fagulhas · r=9 · [AL] · params: Intensidade, Altura/escala
  Na vida real: fagulhas sao particulas incandescentes que sobem com o ar quente, esfriando de amarelo para vermelho ate apagar, com deriva do vento. Modelo: tres particulas por passo com trajetoria fechada: subida + vento + sinuosidade, brilho decai com a vida; halo aditivo.

- **`fogo.explosao`** — Bola de fogo / explosao · r=22 · [AL] · params: Intensidade, Altura/escala
  Na vida real: uma explosao e uma bola de gas quente que se expande em couve-flor turbulenta: nucleo branco, borda laranja e fumaca escura que sobe. Modelo: no fim do gesto: dezenas de bolhas aditivas distribuidas em esfera por ruido (maiores e mais frias na borda) + anel de fumaca escura (Normal) + flash.

- **`fogo.papel-queimado`** — Borda de papel queimando · r=9 · [AL] · params: Intensidade, Altura/escala
  Na vida real: o papel queima de uma frente: a borda fica preta e quebradica, e um fio de brasa laranja corre na linha de combustao, comendo para dentro. Modelo: ao longo do traco: faixa de cinza/carvao irregular (ruido) + linha de brasa aditiva que pulsa + pontos de brasa e fiapo de fumaca.

- **`fogo.lava`** — Lava · r=16 · [AL] · params: Intensidade, Altura/escala
  Na vida real: lava fresca e laranja incandescente; ao esfriar forma crosta escura que racha e deixa a luz do magma vazar pelas fendas. Modelo: base de magma luminoso (aditivo), crosta escura por celulas de Worley cobrindo ~70% e fendas brilhantes nas fronteiras das celulas.


## fumaca (7)

- **`fumaca.cinza`** — Fumaça · r=14 · [A] · params: Intensidade, Altura/escala
  Na vida real: fumaca e ar quente carregando particulas de fuligem: sobe em coluna, se alarga e fica mais clara e transparente ao se misturar com o ar. Modelo: particulas-bolha (mascaras fbm) sobem em coluna: cada uma cresce, clareia/esmaece, deriva com o vento e com ruido de dobra (curl), com transparencia caindo com a idade.

- **`fumaca.preta`** — Fumaça densa preta · r=16 · [A] · params: Intensidade, Altura/escala
  Na vida real: queima de oleo/pneu libera fuligem em quantidade: coluna negra opaca que sobe mais devagar e demora a clarear. Modelo: particulas-bolha (mascaras fbm) sobem em coluna: cada uma cresce, clareia/esmaece, deriva com o vento e com ruido de dobra (curl), com transparencia caindo com a idade.

- **`fumaca.vapor`** — Vapor · r=12 · [A] · params: Intensidade, Altura/escala
  Na vida real: vapor e gotinhas de agua: branco, sobe rapido, se dissolve logo; mais leve que a fumaca. Modelo: particulas-bolha (mascaras fbm) sobem em coluna: cada uma cresce, clareia/esmaece, deriva com o vento e com ruido de dobra (curl), com transparencia caindo com a idade.

- **`fumaca.magica`** — Fumaça mágica · r=14 · [AL] · params: Intensidade, Altura/escala
  Na vida real: fumaca de feitico: mesma dinamica da fumaca real mas emissiva, com cor que muda ao subir e brilho proprio. Modelo: particulas-bolha (mascaras fbm) sobem em coluna: cada uma cresce, clareia/esmaece, deriva com o vento e com ruido de dobra (curl), com transparencia caindo com a idade.

- **`fumaca.neblina`** — Névoa / neblina · r=40 · [A] · params: Intensidade, Altura/escala
  Na vida real: neblina e nuvem rente ao solo: camadas muito largas e de baixo contraste que se deslocam na horizontal e engolem os detalhes distantes. Modelo: puffs enormes e quase transparentes, deriva horizontal, mais densa perto da linha do traco, sem subida.

- **`fumaca.poeira`** — Nuvem de poeira · r=13 · [A] · params: Intensidade, Altura/escala
  Na vida real: poeira levantada por um impacto/pisada: nuvem marrom-clara que se espalha para os lados e cai, com graos soltos. Modelo: puffs que se expandem lateralmente (nao sobem), cor de terra, com graos de poeira pontilhados ao redor.

- **`fumaca.tinta-agua`** — Tinta na água · r=9 · [A] · params: Intensidade, Altura/escala
  Na vida real: tinta solta na agua forma filamentos que se enrolam em vortices e afinam, com franjas translucidas. Modelo: filamentos que seguem um campo de ruido (fluxo) a partir do traco: cada um e um caminho curvo de raio decrescente e alpha decrescente.


## ceu (9)

- **`ceu.estrelas`** — Campo de estrelas · r=26 · [AL] · params: Intensidade, Altura/escala
  Na vida real: no ceu real poucas estrelas sao brilhantes e a maioria e quase invisivel (magnitude); as brilhantes mostram cintilacao e cores (azuis quentes, laranjas frias). Modelo: distribuicao de magnitude (lei de potencia): 85% pontos finos, 12% medias com halo, 3% grandes com cruz de brilho; cintila com o frame.

- **`ceu.estrela-cadente`** — Estrela cadente · r=5 · [L] · params: Intensidade, Altura/escala
  Na vida real: um meteoro e um graozinho que queima na atmosfera: cabeca muito brilhante e cauda que esmaece rapido, mais fina no fim. Modelo: ao longo do traco: linha aditiva cuja intensidade cresce em direcao a cabeca (posicao atual) e afina para a cauda; ponto-cabeca com halo.

- **`ceu.aurora`** — Aurora boreal · r=30 · [AL] · params: Intensidade, Altura/escala
  Na vida real: particulas solares excitam o oxigenio/nitrogenio na alta atmosfera: cortinas verticais, base verde nitida e topo vermelho/violeta difuso, ondulando. Modelo: colunas verticais de raios (aditivas) a partir do traco: altura/intensidade por ruido, gradiente verde->ciano->violeta no alto, ondula com o frame.

- **`ceu.arco-iris`** — Arco-íris · r=28 · params: Intensidade, Altura/escala
  Na vida real: a luz refrata em gotas: sete cores em ordem fixa (vermelho por fora, violeta por dentro), transparente e com bordas suaves, e as bandas sao paralelas. Modelo: 7 faixas paralelas deslocadas pela normal do traco, cada uma com cor espectral, translucidas (0.45) e bordas suaves; sobreposicao suave entre vizinhas.

- **`ceu.sol`** — Sol com raios · r=24 · [AL] · params: Intensidade, Altura/escala
  Na vida real: o sol e um disco quase branco, com halo largo laranja (espalhamento atmosferico) e raios crepusculares em leque. Modelo: no ponto inicial: disco quente, bloom de duas escalas e 12 raios longos aditivos de comprimento irregular; gira devagar com o tempo.

- **`ceu.lua`** — Lua com halo · r=30 · [L] · params: Intensidade, Altura/escala
  Na vida real: a lua e um disco cinza-claro com mares escuros e crateras e um halo frio de espalhamento. Modelo: disco com gradiente, manchas (mares) por fbm, crateras com sombra/realce deslocados e halo azulado aditivo.

- **`ceu.nebulosa`** — Nebulosa / galáxia · r=36 · [AL] · params: Intensidade, Altura/escala
  Na vida real: nebulosas sao nuvens de gas ionizado: filamentos coloridos (H-alfa vermelho, O-III azul-esverdeado) com estrelas jovens embutidas. Modelo: gas aditivo por fbm distorcido (domain warping) com matizes variando ao longo do traco, mais um campo de estrelas finas.

- **`ceu.cometa`** — Cometa · r=9 · [L] · params: Intensidade, Altura/escala
  Na vida real: um cometa tem nucleo com coma brilhante e duas caudas: de poeira (curva, amarelada) e de ions (reta, azulada, aponta contra o sol). Modelo: cabeca na posicao final com coma; duas caudas aditivas: poeira curvada e plasma azul reto, afinando.

- **`ceu.por-do-sol`** — Brilho de pôr do sol · r=34 · [L] · params: Intensidade, Altura/escala
  Na vida real: no crepusculo o ceu faz gradiente de laranja no horizonte, rosa, lilas e azul-noite, com faixas largas e suaves. Modelo: faixas largas muito suaves empilhadas perpendicularmente ao traco, cor interpolada pela ordem do gradiente, mistura Screen.


## carimbo-flores (16)

- **`zip.stamp_flower2`** — Flor de cerejeira (sakura) · r=24 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower2`
  Na vida real: Cinco pétalas com recorte em V, rosa-pálido que clareia nas pontas e escurece no coração; as flores brotam em cachos ao longo do galho. Modelo: Flores espaçadas ao longo do traço, rotação livre, paleta de rosas, coração mais escuro por camada extra e sombra de contato; botão menor na ponta do traço. Tamanho cresce com a pressão.

- **`zip.stamp_flower3`** — Crisântemo · r=24 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower3`
  Na vida real: Dezenas de pétalas finas em raios, dispostas em camadas concêntricas; cores de amarelo, branco e bronze. Modelo: Duas camadas de pétalas-raio (a interna menor, girada e mais clara) sobre sombra de contato; paleta de crisântemo. Tamanho cresce com a pressão.

- **`zip.stamp_flower4`** — Ameixeira (ume) · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower4`
  Na vida real: Flor redonda de cinco pétalas arredondadas com estames no centro; floresce ainda no inverno. Modelo: Pétalas em tons de ameixa, coração escurecido e cinco estames dourados desenhados em volta do centro. Tamanho cresce com a pressão.

- **`zip.stamp_flower5`** — Campânula · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower5`
  Na vida real: Flor em sino de cinco lóbulos, azul-violeta, garganta clara. Modelo: Cores azul/violeta aleatórias e garganta creme por camada pequena clara no centro. Tamanho cresce com a pressão.

- **`zip.stamp_flower6`** — Glória-da-manhã · r=24 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower6`
  Na vida real: Trombeta aberta, borda ondulada, estrela branca no fundo e miolo amarelo. Modelo: Corpo colorido (azul, roxo, rosa) + estrela branca translúcida + miolo amarelo; a estrela dá o brilho típico. Tamanho cresce com a pressão.

- **`zip.stamp_flower7`** — Cravo · r=24 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower7`
  Na vida real: Pétalas franjadas em camadas amassadas, vermelho, rosa ou branco. Modelo: Três camadas de recortes girados (efeito babado), a de cima mais clara, a de baixo mais escura. Tamanho cresce com a pressão.

- **`zip.stamp_flower8`** — Rosa · r=26 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower8`
  Na vida real: Pétalas enroladas em espiral, escuras no miolo apertado e claras nas bordas externas; a rosa fica de frente, quase sem girar. Modelo: Rotação pequena (a rosa nasce 'de pé'), espiral escura em duas camadas de miolo e sombra, paleta vermelha/amarela/rosa. Tamanho cresce com a pressão.

- **`zip.stamp_flower1`** — Chuva de pétalas · r=18 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower1`
  Na vida real: pétalas soltas de sakura giram sobre o próprio eixo e planam com o vento, caindo devagar. Modelo: grupos de 3-5 pétalas por passo, caindo em ordem aleatória abaixo do traço com deriva do vento (StrokeParams.wind), rotação contínua, achatamento (aspect) simulando a pétala girando de lado e transparência crescente com a queda.

- **`zip.stamp_flower1o`** — Pétala em contorno (bordado) · r=16 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower1o`
  Na vida real: o desenho de pétala única em contorno é o motivo dos brasões japoneses (kamon), carimbos de bordado e xilogravura: linha única, sempre idêntica, repetida em ritmo. Modelo: motivo repetido com rotação em degraus regulares (girando 60° a cada carimbo, nunca aleatório), tamanho com leve respiração, relevo (luz/sombra deslocadas) para parecer gravado no papel.

- **`zip.stamp_flower2o`** — Sakura em contorno (renda) · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower2o`
  Na vida real: o desenho de sakura em contorno é o motivo dos brasões japoneses (kamon), carimbos de bordado e xilogravura: linha única, sempre idêntica, repetida em ritmo. Modelo: motivo repetido com rotação em degraus regulares (girando 36° a cada carimbo, nunca aleatório), tamanho com leve respiração, relevo (luz/sombra deslocadas) para parecer gravado no papel.

- **`zip.stamp_flower3o`** — Crisântemo em contorno (kamon) · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower3o`
  Na vida real: o desenho de crisântemo em contorno é o motivo dos brasões japoneses (kamon), carimbos de bordado e xilogravura: linha única, sempre idêntica, repetida em ritmo. Modelo: motivo repetido com rotação em degraus regulares (girando 15° a cada carimbo, nunca aleatório), tamanho com leve respiração, relevo (luz/sombra deslocadas) para parecer gravado no papel.

- **`zip.stamp_flower4o`** — Ameixeira em contorno (kamon) · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower4o`
  Na vida real: o desenho de ume em contorno é o motivo dos brasões japoneses (kamon), carimbos de bordado e xilogravura: linha única, sempre idêntica, repetida em ritmo. Modelo: motivo repetido com rotação em degraus regulares (girando 36° a cada carimbo, nunca aleatório), tamanho com leve respiração, relevo (luz/sombra deslocadas) para parecer gravado no papel.

- **`zip.stamp_flower5o`** — Campânula em contorno · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower5o`
  Na vida real: o desenho de campânula em contorno é o motivo dos brasões japoneses (kamon), carimbos de bordado e xilogravura: linha única, sempre idêntica, repetida em ritmo. Modelo: motivo repetido com rotação em degraus regulares (girando 36° a cada carimbo, nunca aleatório), tamanho com leve respiração, relevo (luz/sombra deslocadas) para parecer gravado no papel.

- **`zip.stamp_flower6o`** — Glória-da-manhã em contorno · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower6o`
  Na vida real: o desenho de glória-da-manhã em contorno é o motivo dos brasões japoneses (kamon), carimbos de bordado e xilogravura: linha única, sempre idêntica, repetida em ritmo. Modelo: motivo repetido com rotação em degraus regulares (girando 36° a cada carimbo, nunca aleatório), tamanho com leve respiração, relevo (luz/sombra deslocadas) para parecer gravado no papel.

- **`zip.stamp_flower7o`** — Cravo em contorno · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower7o`
  Na vida real: o desenho de cravo em contorno é o motivo dos brasões japoneses (kamon), carimbos de bordado e xilogravura: linha única, sempre idêntica, repetida em ritmo. Modelo: motivo repetido com rotação em degraus regulares (girando 24° a cada carimbo, nunca aleatório), tamanho com leve respiração, relevo (luz/sombra deslocadas) para parecer gravado no papel.

- **`zip.stamp_flower8o`** — Rosa em contorno · r=24 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_flower8o`
  Na vida real: o desenho de rosa em contorno é o motivo dos brasões japoneses (kamon), carimbos de bordado e xilogravura: linha única, sempre idêntica, repetida em ritmo. Modelo: motivo repetido com rotação em degraus regulares (girando 90° a cada carimbo, nunca aleatório), tamanho com leve respiração, relevo (luz/sombra deslocadas) para parecer gravado no papel.


## carimbo-folhas (12)

- **`zip.stamp_leaf1`** — Galho de folhas · r=20 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf1`
  Na vida real: as folhas saem do galho alternadas, com um pecíolo que as afasta ~50° da direção de crescimento; a face de cima pega luz e fica mais clara, a de baixo, sombra. Modelo: traço = galho (fio marrom); em cada passo nascem folhas dos dois lados com ângulo ±50° (+jitter), âncora na base da folha, sombra, corpo e brilho superior.

- **`zip.stamp_leaf1o`** — Galho de folhas em contorno · r=20 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf1o`
  Na vida real: ilustração botânica a nanquim, só o contorno das folhas, alternadas ao longo do ramo. Modelo: mesma filotaxia do galho colorido, mas folhas só em linha verde-escura e alternando lados (um lado por vez), sem sombra.

- **`zip.stamp_leaf2`** — Folhas de ginkgo · r=24 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf2`
  Na vida real: leque com pecíolo longo que balança ao menor vento; fica dourado no outono, com variação verde. Modelo: leques nos dois lados do galho, ângulo base ±75° mais oscilação senoidal por frame (animação!), dourado com algumas verdes e brilho interno.

- **`zip.stamp_leaf2o`** — Ginkgo em contorno · r=24 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf2o`
  Na vida real: ginkgo prensado/herbário, só o desenho do leque. Modelo: um leque por passo, alternando lados, cor de tinta marrom, oscilação por frame.

- **`zip.stamp_leaf3`** — Folhas de bordo em queda · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf3`
  Na vida real: a folha de bordo muda de verde para amarelo, laranja e vermelho e cai girando (tombamento) em volta do eixo do pecíolo. Modelo: a cor percorre verde→amarelo→laranja→vermelho com o comprimento do traço; cada passo solta de 1 a 3 folhas que caem abaixo do traço, com achatamento por rotação (aspect), sombra e perda de opacidade na queda.

- **`zip.stamp_leaf3o`** — Bordo em contorno · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf3o`
  Na vida real: carimbo clássico de folha de bordo (símbolo), repetido como fita decorativa. Modelo: carimbo em linha, girando 25° a cada passo, gravado no papel.

- **`zip.stamp_leaf4`** — Trevo florido (cobertura) · r=18 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf4`
  Na vida real: o trevo cobre o chão em tapetes de folhas sobrepostas, com uma flor branca aqui e ali. Modelo: aglomerados de 3-5 folhas com rotação e tamanho aleatórios, sombra de contato entre elas e flor branca rara.

- **`zip.stamp_leaf4o`** — Trevo em contorno · r=20 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf4o`
  Na vida real: motivo de trevo/sakurakamon em linha, usado em fitas e carimbos. Modelo: repetição regular girando 36° por passo com relevo.

- **`zip.stamp_leaf5`** — Trevo da sorte · r=20 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf5`
  Na vida real: em cerca de 1 a cada 5.000 trevos aparece o de quatro folhas. Modelo: tapete de trevos comuns (aglomerados) e, com ~16% de chance por passo, um trevo de quatro folhas maior, mais claro e com um brilho de sorte.

- **`zip.stamp_leaf5o`** — Trevo de quatro folhas em contorno · r=20 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaf5o`
  Na vida real: amuleto desenhado em linha. Modelo: repetição alternando inclinação ±12° e espelhamento, relevo verde-escuro.

- **`zip.stamp_leaves1`** — Folhas levadas pelo vento · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaves1`
  Na vida real: uma rajada carrega folhas em fila, as mais antigas ficando para trás e dispersas, girando. Modelo: cada passo desenha 4 cópias em esteira atrás do ponto, cada vez menores/transparentes, com ondulação lateral e rotação crescente.

- **`zip.stamp_leaves2`** — Estilhaços de folha seca · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_leaves2`
  Na vida real: folha seca esfarela em lascas angulares quando pisada. Modelo: explosão de 3-5 estilhaços lançados radialmente do traço, menores e mais transparentes quanto mais longe, em tons de terra.


## carimbo-grama (7)

- **`zip.stamp_grass1`** — Samambaia · r=30 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_grass1`
  Na vida real: as frondes se desenrolam de dentro para fora e se abrem em leque a partir da base. Modelo: frondes alternando lados em ângulos 18-46° da vertical, crescendo (desenrolando) ao longo do traço, três camadas de sombra/luz.

- **`zip.stamp_grass2`** — Ervas daninhas · r=24 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_grass2`
  Na vida real: tufos esparsos, de alturas muito diferentes. Modelo: 1-3 tufos por passo, de pé (nunca giram com o traço), altura por ruído, inclinação do vento.

- **`zip.stamp_grass3`** — Capim comprido · r=30 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_grass3`
  Na vida real: lâminas longas que dobram para o vento, pontas mais claras ao sol. Modelo: lâminas altas, inclinação grande com o vento (StrokeParams.wind), ponta clara por camada extra.

- **`zip.stamp_grass4`** — Capim seco do cerrado · r=30 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_grass4`
  Na vida real: capim ressecado, palha amarelada, tombado em feixes. Modelo: tufos dourados com maior variação de altura e inclinação por ruído.

- **`zip.stamp_grass5`** — Moita de capim denso · r=34 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_grass5`
  Na vida real: touceira cerrada, centro escuro sombreado, pontas claras. Modelo: 2-4 touceiras por passo, camada de fundo mais escura (profundidade), pontas iluminadas.

- **`zip.stamp_grass6`** — Juncos e taboas · r=36 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_grass6`
  Na vida real: juncos altos em beira de água, retos e finos, quase sem dobrar. Modelo: poucas hastes por passo, altas, com pouca inclinação (ruído baixo).

- **`zip.stamp_grass7`** — Matinho com florzinhas · r=26 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_grass7`
  Na vida real: ervas miúdas florescem com pontinhos brancos e amarelos na ponta da haste. Modelo: tufos pequenos com 40% de chance de florzinha na ponta de cada lâmina.


## carimbo-elementos (12)

- **`zip.stamp_snow1`** — Flocos de neve · r=18 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_snow1`
  Na vida real: cada floco tem simetria de seis lados; os próximos da câmera parecem grandes e nítidos, os distantes, pequenos e esmaecidos (profundidade). Modelo: 3-6 flocos por passo espalhados num disco, escala e opacidade pela profundidade aleatória, brilho extra nos mais próximos, deriva do vento.

- **`zip.stamp_snow2`** — Nevasca com rastro · r=18 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_snow2`
  Na vida real: em queda, o floco deixa um rastro de movimento e há muita poeira de neve miúda. Modelo: cada floco com 3 fantasmas de movimento acima (direção da queda + vento) e pontinhos de neve fina em volta.

- **`zip.stamp_drop`** — Gotas sobre vidro · r=14 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_drop`
  Na vida real: gota em superfície é uma lente: borda espessa que entorta a luz (escura), centro claro, reflexo de janela e, às vezes, escorre deixando rastro molhado. Modelo: anel escuro, corpo claro, 2 reflexos brancos, sombra projetada e 18% de chance de rastro úmido.

- **`zip.stamp_drop_o`** — Orvalho no fio · r=18 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_drop_o`
  Na vida real: gotas de orvalho pendem de uma teia/fio, grandes no meio, menores nas pontas. Modelo: o traço vira um fio fino; as gotas (contorno + preenchimento claro) penduradas pela ponta, tamanho pela pressão, reflexo de luz.

- **`zip.stamp_splash`** — Respingo de tinta · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_splash`
  Na vida real: ao bater, a gota espalha uma poça irregular e lança gotículas alongadas na direção do movimento, menores e mais finas quanto mais longe. Modelo: mancha com rotação aleatória + brilho úmido + 7-13 gotículas elípticas alinhadas ao traço.

- **`zip.stamp_spider_net`** — Teia de aranha · r=24 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_spider_net`
  Na vida real: a teia é radial (fios secos) mais espiral; o orvalho forma pérolas que refletem luz, e fios-âncora ligam uma teia à outra. Modelo: teia grande no início, teias menores ao longo do traço ligadas por fio com curva (catenária), gotas de orvalho com sombra e brilho.

- **`zip.clouds01`** — Nuvem de tempestade · r=36 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `clouds01`
  Na vida real: cumulonimbus tem base escura e plana, corpo cinza-azulado e topo claro onde pega sol. Modelo: três passadas por nuvem (sombra, corpo, topo) com espelhamento e tamanho aleatórios.

- **`zip.clouds02`** — Cúmulo de bom tempo · r=36 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `clouds02`
  Na vida real: cúmulos são brancos, com base azulada em sombra e topo quente de sol. Modelo: base azulada, corpo branco, topo creme; empilhamento denso para formar bancos.

- **`zip.clouds03`** — Cirros e virga · r=36 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `clouds03`
  Na vida real: cirros são fios de gelo esticados pelo vento em altitude; virga é chuva que evapora antes de tocar o chão. Modelo: fiapos alinhados perpendicularmente à direção do traço, duas camadas translúcidas (sombra e luz) sobre o céu.

- **`zip.fur01`** — Tufos de pelo · r=22 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `fur01`
  Na vida real: o pelo tem subpelo denso escuro e pelos-guarda mais longos e claros que pegam a luz, todos deitados no sentido do corpo. Modelo: tufos muito densos, orientados pela direção do traço com ±jitter, em três camadas (subpelo, pelo, brilho).

- **`zip.oriental_shan_shui`** — Rochedo de nanquim (shan shui) · r=28 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `oriental_shan_shui`
  Na vida real: na pintura chinesa shan shui, a profundidade vem de camadas de tinta cada vez mais escuras: pálido (longe), médio e acento escuro (perto), com pincel seco nas bordas. Modelo: três lavagens sobrepostas por carimbo (10%, 20%, 42% de tinta), a escura menor, deslocada e com dissolve para efeito de pincel seco.

- **`zip.pierced`** — Seixos furados · r=20 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `pierced`
  Na vida real: pedras furadas pela água formam cascalho; cada uma projeta sombra no chão e tem luz no topo. Modelo: seixos de tamanhos 0.4-1.15R espalhados, cinzas/terrosos, sombra de contato projetada, luz no topo.


## carimbo-animais (8)

- **`zip.stamp_dragonfly`** — Libélula · r=20 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_dragonfly`
  Na vida real: a libélula bate as quatro asas, voa em zigue-zague suave e a sombra corre no chão. Modelo: um inseto a cada ~5 raios, cabeça sempre na direção do voo, ondulação lateral senoidal, batida de asas por frame (largura oscila 60-100%), cores iridescentes (turquesa, azul, vermelha) e sombra deslocada.

- **`zip.stamp_dragonfly_o`** — Libélula estroboscópica · r=18 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_dragonfly_o`
  Na vida real: foto de longa exposição/estroboscópica mostra cada pose do voo. Modelo: no traço, a libélula em contorno é repetida atrás com 4 poses de asa em opacidade decrescente, como quadros-fantasma de animação (smear).

- **`zip.stamp_swallowtail`** — Borboleta cauda-de-andorinha · r=22 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_swallowtail`
  Na vida real: voo irregular, em ondas, com asas abrindo/fechando por completo; amarela com padrão escuro. Modelo: trajetória ondulada em dois eixos, batida de asas por frame (largura 28-100%, fecha quase de perfil), amarelo com camada interna escura simulando o padrão, sombra.

- **`zip.stamp_feather`** — Penas ao vento · r=22 · [A] · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_feather`
  Na vida real: a pena cai balançando como pêndulo, o ar dobra a lâmina e ela muda de lado. Modelo: penas alternando em ambos os lados do traço, ângulo oscilando por frame, ordem de pilha variada, cor por paleta (branca, creme, azul, cinza) com leve brilho.

- **`zip.stamp_cat_footprint_one`** — Pegadas de gato · r=15 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_cat_footprint_one`
  Na vida real: o gato anda em linha, pata direita e esquerda alternadas; as marcas ficam mais fracas à medida que ele se afasta e a almofada central afunda mais. Modelo: espelha a pata a cada passo, desloca ±0.75R do centro, gira com a direção, passada = 3.2R, esmaece e encolhe com a distância, sujeira de lama atrás.

- **`zip.stamp_cat_footprint_one_o`** — Pegadas na neve (relevo) · r=15 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_cat_footprint_one_o`
  Na vida real: pegada na neve é um relevo: lado sombreado e lado iluminado. Modelo: contorno desenhado em azul-sombra com highlight branco deslocado, esmaecendo ao longe.

- **`zip.stamp_cat_footprints_both`** — Pegadas de pata dupla · r=20 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_cat_footprints_both`
  Na vida real: ao trotar, patas da frente e de trás pousam quase juntas (par). Modelo: carimbo-par girado para a direção, alterna espelhamento, passada 4.6R, esmaece e encolhe, leve sombra.

- **`zip.stamp_cat_footprints_both_o`** — Pegadas arco-íris · r=20 · params: Densidade, Variação, Cores naturais (1) / cor do pincel (0), Escala pela pressão · textura: `stamp_cat_footprints_both_o`
  Na vida real: pata suja de tinta colorida deixa marcas que mudam de cor a cada rodada de pintura. Modelo: par em contorno com cor que percorre o círculo cromático ao longo do traço (ou do degradê cor→cor2).


## carimbo-formas (18)

- **`zip.stamp_circle`** — Disco chanfrado · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_circle`
  Na vida real: botões, fichas e pastilhas têm borda arredondada e brilho no topo. Modelo: disco com sombra projetada, corpo e luz interna deslocada; espaçamento regular, tamanho por pressão.

- **`zip.stamp_pcir_i`** — Anel suave (interno) · r=22 · [L] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_pcir_i`
  Na vida real: lente de luz com miolo vazio e aro difuso (bokeh). Modelo: anéis de bordas moles que se sobrepõem por soma de luz, deslocados aleatoriamente — lembram bolhas de bokeh.

- **`zip.stamp_pcir_o`** — Anel suave (externo) · r=26 · [L] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_pcir_o`
  Na vida real: halo de lâmpada fora de foco, mais brilhante na borda. Modelo: anéis grandes de aro externo com opacidade baixa e acumulada, cor variando por matiz.

- **`zip.stamp_square`** — Ladrilho quadrado · r=16 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_square`
  Na vida real: azulejos e pixels ficam lado a lado com juntas finas. Modelo: quadrados que acompanham a direção do traço, com chanfro e variação sutil de tom, formando mosaico.

- **`zip.stamp_poly3`** — Triângulo tesselado · r=18 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_poly3`
  Na vida real: triângulos equiláteros encaixam virando o sentido a cada peça. Modelo: triângulos alternando 180° ao longo do traço, para formar faixas de padrão geométrico.

- **`zip.stamp_poly3b`** — Cunha triangular · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_poly3b`
  Na vida real: lascas e pontas de seta cortantes. Modelo: cunha orientada pela direção do movimento, comprimento cresce com a pressão, leve rotação aleatória como estilhaço.

- **`zip.stamp_poly5`** — Pentágono facetado · r=18 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_poly5`
  Na vida real: pentágonos formam bolas de futebol e cristais. Modelo: pentágonos girando aleatoriamente em múltiplos de 72° com bisel de luz, escala variável.

- **`zip.stamp_poly6`** — Colmeia hexagonal · r=16 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_poly6`
  Na vida real: os favos das abelhas são hexágonos que encaixam sem folga. Modelo: hexágonos com espaçamento de encaixe (√3·r/2), cor em tons de mel e bisel de cera.

- **`zip.stamp_ppoly5_i`** — Pentágono macio (interno) · r=22 · [L] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_ppoly5_i`
  Na vida real: formas desfocadas de abertura de lente pentagonal (íris de 5 lâminas). Modelo: bokeh pentagonal aditivo com miolo suave, rotação aleatória.

- **`zip.stamp_ppoly5_o`** — Pentágono macio (aro) · r=24 · [L] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_ppoly5_o`
  Na vida real: bokeh de lente com aro mais brilhante. Modelo: pentágonos de aro luminoso e centro quase vazio, somados como luz.

- **`zip.stamp_star`** — Estrela cintilante · r=20 · [A] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_star`
  Na vida real: estrelas visíveis têm brilhos muito diferentes: poucas grandes, muitas pequenas, e cintilam. Modelo: tamanhos em lei de potência, brilho que oscila com o quadro de animação e raios de brilho (glint) aditivos.

- **`zip.stamp_star_r`** — Estrela arredondada · r=18 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_star_r`
  Na vida real: estrelas de papel e adesivos têm pontas arredondadas e sobem em brilho no centro. Modelo: estrelas com bisel, rotação aleatória, cor variando entre amarelos e laranjas.

- **`zip.stamp_pentagram1`** — Pentagrama (linhas) · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_pentagram1`
  Na vida real: símbolo desenhado com compasso e régua, linhas finas e vértices exatos. Modelo: estrela de 5 pontas em linha dupla manuscrita, sempre com uma ponta para cima (não gira), pressão controla tamanho.

- **`zip.stamp_pentagram2`** — Pentagrama (estrela cheia) · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_pentagram2`
  Na vida real: selo desenhado de uma só volta de caneta. Modelo: estrela de linha com preenchimento levemente transparente, rotação alinhada ao traço (a ponta aponta para onde se vai).

- **`zip.stamp_pentagram3`** — Pentagrama no círculo · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_pentagram3`
  Na vida real: círculo mágico/selo inscrito. Modelo: selo em linha dupla que gira lentamente a cada carimbo (passo de 18°), como um sinete carimbado repetidamente.

- **`zip.stamp_hexagram1`** — Hexagrama fino · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_hexagram1`
  Na vida real: estrela de seis pontas de dois triângulos sobrepostos. Modelo: linha fina com dupla traçada, orientação fixa, tamanho por pressão.

- **`zip.stamp_hexagram2`** — Hexagrama entrelaçado · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_hexagram2`
  Na vida real: dois triângulos entrelaçados passando por cima e por baixo. Modelo: carimbo com bisel leve, girando aleatoriamente em múltiplos de 30° para efeito de ornamento.

- **`zip.stamp_hexagram3`** — Hexagrama no círculo · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_hexagram3`
  Na vida real: selo de proteção em círculo duplo. Modelo: sinete que gira a cada passo e se afasta do traço alternando lados, como carimbos presos num selo cerimonial.


## carimbo-simbolos (25)

- **`zip.stamp_kira4`** — Brilho cruz 4 pontas · r=22 · [AL] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_kira4`
  Na vida real: o brilho em cruz vem da difração nas lâminas do diafragma ou do filtro estrela; é luz, não tinta. Modelo: raios aditivos que variam de tamanho em lei de potência e piscam com o quadro.

- **`zip.stamp_kira6`** — Brilho 6 pontas · r=22 · [AL] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_kira6`
  Na vida real: seis raios surgem de lentes com diafragma hexagonal ou de cristais de gelo. Modelo: estrela de seis raios aditiva, rotação aleatória, cor entre branco e azul-gelo.

- **`zip.stamp_kira8`** — Brilho 8 pontas · r=24 · [AL] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_kira8`
  Na vida real: lentes de 8 lâminas e fontes muito brilhantes fazem raios longos de 8 pontas. Modelo: raio aditivo com centro quase branco; rotação por quadro (cintilação animada).

- **`zip.stamp_kira_diamond`** — Estrela losango · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_kira_diamond`
  Na vida real: brilho de joia ou purpurina em forma de losango alongado. Modelo: losangos finos verticais com glint aditivo em parte deles, tamanho em lei de potência.

- **`zip.stamp_kira_diamond_o`** — Estrela losango (linha) · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_kira_diamond_o`
  Na vida real: desenho de brilho feito com linha fina, como em quadrinhos. Modelo: contorno duplo manuscrito, tamanho aleatório e giro de 0/45° leve.

- **`zip.stamp_flare`** — Clarão (flare) · r=36 · [L] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_flare`
  Na vida real: clarão de lente é luz espalhada que somada ao fundo clareia tudo ao redor da fonte. Modelo: halo largo aditivo + núcleo menor mais branco, desloca por passo.

- **`zip.light02`** — Bloom suave · r=30 · [L] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `light02`
  Na vida real: bloom é luz que vaza em volta de pontos muito claros (olho/câmera). Modelo: pequeno núcleo + halo largo aditivos, acumulam ao passar mais de uma vez sem estourar.

- **`zip.stamp_gear_wheel01`** — Engrenagem rolante · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_gear_wheel01`
  Na vida real: engrenagens vizinhas giram em sentidos opostos e os dentes encaixam. Modelo: o ângulo vem do comprimento percorrido (rolagem), vizinhas contra-rotacionam com meio dente de defasagem e sombra projetada.

- **`zip.stamp_gear_wheel01o`** — Engrenagem rolante (linha) · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_gear_wheel01o`
  Na vida real: esquema técnico de engrenagens. Modelo: contorno em dupla linha que gira por rolagem, alternando o sentido.

- **`zip.stamp_gear_wheel02`** — Roda dentada · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_gear_wheel02`
  Na vida real: rodas dentadas de relógio rolam sobre a pista e giram proporcionalmente. Modelo: rolagem pura (ângulo = distância/raio) com sombra; todas giram no mesmo sentido como rodas de uma esteira.

- **`zip.stamp_gear_wheel02o`** — Roda dentada (linha) · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_gear_wheel02o`
  Na vida real: planta técnica de roda com raios. Modelo: contorno duplo que rola pelo caminho, sentido alternado.

- **`zip.stamp_pinwheel`** — Cata-vento · r=20 · [A] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_pinwheel`
  Na vida real: o cata-vento gira mais rápido quanto mais vento recebe. Modelo: o giro acumulado cresce com a velocidade da caneta e com o quadro; em alta velocidade surgem fantasmas de desfoque de movimento.

- **`zip.stamp_pinwheel_o`** — Cata-vento (linha) · r=20 · [A] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_pinwheel_o`
  Na vida real: ícone de cata-vento em traços. Modelo: contorno duplo manuscrito que gira com a velocidade, sem preenchimento.

- **`zip.stamp_waterwheel`** — Roda d'água · r=24 · [A] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_waterwheel`
  Na vida real: a roda d'água gira num ritmo constante empurrada pela correnteza. Modelo: giro constante por quadro (animação) mais um pouco pela velocidade da mão, com leve rastro de movimento.

- **`zip.stamp_waterwheel_o`** — Roda d'água (linha) · r=24 · [A] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_waterwheel_o`
  Na vida real: desenho técnico de roda de pás. Modelo: contorno duplo que gira por quadro, mais devagar que a versão cheia.

- **`zip.stamp_heart`** — Corações flutuantes · r=16 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_heart`
  Na vida real: nos quadrinhos corações (emote) sobem, diminuem e somem. Modelo: um coração no traço mais cópias que sobem com vento e balanço lateral, menores e mais transparentes conforme sobem; pressão faz pulsar.

- **`zip.stamp_doublet_note`** — Colcheias duplas · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_doublet_note`
  Na vida real: notas escritas numa pauta ocupam alturas (notas) diferentes. Modelo: desenha uma pauta de 5 linhas ao longo do traço e coloca notas em posições de altura discretas sobre ela.

- **`zip.stamp_eighth_note`** — Colcheia · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_eighth_note`
  Na vida real: uma colcheia sozinha sobe a melodia. Modelo: nota única com pauta, ligeira inclinação seguindo a direção e posição de altura aleatória por carimbo.

- **`zip.stamp_king_crown`** — Coroa de rei · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_king_crown`
  Na vida real: coroas são de metal polido, com luz forte no topo e sombra embaixo, e ficam sempre em pé. Modelo: nunca gira; sombra, corpo dourado, brilho superior deslocado e glint ocasional; tamanho por pressão.

- **`zip.stamp_king_crown_o`** — Coroa de rei (linha) · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_king_crown_o`
  Na vida real: brasão desenhado a traço. Modelo: contorno duplo manuscrito, sempre em pé, tamanho por pressão.

- **`zip.stamp_queen_crown`** — Coroa de rainha · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_queen_crown`
  Na vida real: coroa de rainha tem pontas arredondadas e pérolas. Modelo: corpo em ouro rosado com realce superior e brilho de pedra, sempre em pé.

- **`zip.stamp_queen_crown_o`** — Coroa de rainha (linha) · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_queen_crown_o`
  Na vida real: ícone de realeza em traço. Modelo: contorno duplo, sempre em pé.

- **`zip.stamp_diamond_icon`** — Diamante (ícone) · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_diamond_icon`
  Na vida real: uma gema lapidada disfarça cores quando a luz atravessa (dispersão). Modelo: corpo tingido, luz interna branca, franjas vermelha/azul deslocadas aditivas e brilho em cruz.

- **`zip.stamp_diamond_real_side`** — Diamante lapidado (lateral) · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_diamond_real_side`
  Na vida real: vista lateral mostra coroa, cintura e pavilhão com facetas que refletem diferentes cores. Modelo: máscara de facetas pintadas com cor variável + dispersão cromática + glints, sem girar demais.

- **`zip.stamp_diamond_real_top`** — Diamante lapidado (topo) · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `stamp_diamond_real_top`
  Na vida real: visto de cima o brilhante mostra uma rosa de facetas. Modelo: facetas aleatoriamente giradas, cada gema com matiz próprio, luz interna e cruz de brilho.


## ponta-achatada (10)

- **`zip.flat01`** — Pincel chato: fios soltos · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat01`
  Na vida real: pincel chato velho tem fios que se abrem em leque quando arrastado. Modelo: ponta perpendicular ao traço, fios irregulares radiais, falha de tinta (dry-brush) cresce com a velocidade.

- **`zip.flat02`** — Pincel chato: cerdas esparsas · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat02`
  Na vida real: poucas cerdas ressecadas deixam pontos soltos em fileira. Modelo: ponta de pontos alinhados na perpendicular; arrasta deixando linhas pontilhadas paralelas.

- **`zip.flat03`** — Pincel chato: grade de pontos · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat03`
  Na vida real: rolinho de textura/pente deixa fileiras regulares. Modelo: duas fileiras de pontos perpendiculares ao traço, espaçamento curto produz linhas paralelas.

- **`zip.flat04`** — Pincel chato: poucos pontos · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat04`
  Na vida real: leque com poucas cerdas deixa 6-7 riscos finos. Modelo: ponta de poucos pontos grandes; viram riscos paralelos espaçados, largura por pressão.

- **`zip.flat05`** — Pincel chato: leque de grãos · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat05`
  Na vida real: pincel leque (fan brush) distribui cerdas em arco. Modelo: ponta de grãos alongados em leque; ao arrastar, riscos finos e curtos que se espalham em volta da direção.

- **`zip.flat_calligraphy`** — Pena caligráfica · r=14 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat_calligraphy`
  Na vida real: a pena de ponta chata fixa em 45° faz traços grossos na diagonal e finos no sentido perpendicular. Modelo: elipse com ângulo fixo (param. ângulo fixo ligado); a espessura vem da geometria, não da pressão.

- **`zip.flat_five_lines`** — Pente de 5 linhas · r=18 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat_five_lines`
  Na vida real: o pente de pauta (rastrum) desenha cinco linhas paralelas de uma só vez. Modelo: cinco pontos perpendiculares ao traço, sempre acompanhando a curva, perfeito para pauta/cabos.

- **`zip.flat_line`** — Pincel de listras · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat_line`
  Na vida real: pincel de cerdas largas e marcadas deixa faixas alternadas de tinta e papel. Modelo: elipse com listras horizontais; a ponta fica perpendicular ao traço, mostrando riscos paralelos longos.

- **`zip.flat_real`** — Pincel chato real · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat_real`
  Na vida real: pincel chato carregado arrasta riscos, falhas nas bordas e acumula tinta no início. Modelo: marca de cerdas real, perpendicular ao traço, falha seca com a velocidade e grão de fibras do papel.

- **`zip.flat_rect`** — Pincel retangular (chisel) · r=18 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho, Ângulo fixo (0 = perpendicular ao traço) · textura: `flat_rect`
  Na vida real: marcador/pincel de ponta quadrada pinta faixa de largura constante. Modelo: retângulo chanfrado que fica perpendicular ao traço e preenche faixa sólida; pressão só altera a largura levemente.


## ponta-rede (11)

- **`zip.net1`** — Malha de linhas · r=14 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net1`
  Na vida real: tela de tecido é fiada em linhas paralelas iguais. Modelo: carimbo ancorado à grade do canvas (mesma célula em todo traço), portanto cruzamentos de traços se alinham como um tom/malha contínuo.

- **`zip.net2`** — Grade quadriculada · r=14 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net2`
  Na vida real: papel milimetrado/quadriculado tem grade regular. Modelo: grade ancorada ao canvas; pintar mais de uma vez não duplica células.

- **`zip.net3`** — Rede cruzada · r=14 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net3`
  Na vida real: rede de pesca/cerca de arame forma losangos. Modelo: células de losango alinhadas ao canvas, estendendo-se onde você passa.

- **`zip.net4`** — Rede densa com brilho · r=14 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net4`
  Na vida real: tela de seda tem fios que brilham nos cruzamentos. Modelo: malha de losangos com pontas luminosas, ancorada à grade.

- **`zip.net_chain`** — Corrente 3D · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net_chain`
  Na vida real: elos de corrente alternam: um de frente, outro de perfil (girado 90°). Modelo: elos alternados face/perfil, com sombra projetada e brilho; elos se sobrepõem 1/2 para encaixarem.

- **`zip.net_flash`** — Relâmpago de traço · r=22 · [L] · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net_flash`
  Na vida real: um clarão de luz cria um risco muito fino que afina nas pontas. Modelo: faixa alinhada ao movimento, comprimento e opacidade crescem com a velocidade da caneta.

- **`zip.net_lace`** — Renda · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net_lace`
  Na vida real: a renda tem festões (scallops) repetidos e furos, e a barra fica de um lado. Modelo: segmentos espelhados alternadamente para continuidade, orientados pelo caminho.

- **`zip.net_pile`** — Pilha de fios · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net_pile`
  Na vida real: feixe de fios finos lado a lado, como cabos. Modelo: três linhas paralelas orientadas, afinando no início e abrindo conforme a pressão.

- **`zip.net_rope`** — Corda trançada · r=18 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net_rope`
  Na vida real: corda é feita de cordões trançados cuja fase gira ao longo do comprimento. Modelo: fase avança com o caminho, alternando claro/escuro e espelhando a cada elo; cria sensação de torção.

- **`zip.net_speed`** — Linhas de velocidade · r=18 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net_speed`
  Na vida real: nos quadrinhos, linhas paralelas de velocidade ficam atrás do objeto e esticam com a velocidade. Modelo: traços de comprimento e opacidade proporcionais à velocidade, espalhados na perpendicular atrás da caneta.

- **`zip.net_wedge`** — Cunha de pincel · r=20 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `net_wedge`
  Na vida real: pincel de cunha (sumi/shodō) entra afiado e engrossa. Modelo: fade de entrada por comprimento (taper), largura e opacidade pela pressão, ponta voltada à direção do traço.


## ponta-particulas (14)

- **`zip.circle01`** — Fogos de artifício · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `circle01`
  Na vida real: fogos explodem em raios que se afastam do centro, cada explosão com uma cor. Modelo: explosões radiais com orientação aleatória, escala variável e matiz novo por explosão; esparsas.

- **`zip.circle02`** — Poeira de pontos · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `circle02`
  Na vida real: poeira fina em suspensão é rara e muito pequena. Modelo: pontos minúsculos aleatórios em volta do traço, cada passo solta 2-3 deles com opacidade variável.

- **`zip.circle03`** — Pixels dissolvendo · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `circle03`
  Na vida real: ao se desfazer, uma imagem vira quadradinhos. Modelo: quadrados pequenos rotacionados em múltiplos de 15°, espalhados com tamanhos diferentes — efeito de dissolução digital.

- **`zip.circle04`** — Faíscas alongadas · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `circle04`
  Na vida real: partículas soltas pela fricção deixam rastros curtos na direção do movimento. Modelo: pontos esticados ao longo do traço proporcional à velocidade, espalhados na perpendicular.

- **`zip.circle05`** — Chuva de riscos · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `circle05`
  Na vida real: gotas ou palhas vistas em movimento ficam riscadas na direção do deslocamento. Modelo: riscos curtos orientados à direção, mais longos com velocidade, espalhados em grupo.

- **`zip.circle_particle`** — Esponja de partículas · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `circle_particle`
  Na vida real: esponja marinha carimba manchas irregulares com muitos furos. Modelo: carimbo girado aleatoriamente com 30% de pixels descartados, sobrepõe várias vezes para textura de esponja.

- **`zip.circle_real`** — Esponja real · r=26 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `circle_real`
  Na vida real: esponja natural tem poros grandes e bordas ásperas, pinta em manchas variadas de tom. Modelo: carimbo de poros irregulares, rotação aleatória e variação de tom por carimbo, sobreposição suave.

- **`zip.circle_rough`** — Estêncil áspero · r=26 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `circle_rough`
  Na vida real: pincel de estêncil/pontilhado deixa bordas macias e granulosas, que se acumulam. Modelo: disco rugoso translúcido, baixa opacidade por carimbo, constrói tom ao repassar.

- **`zip.points01`** — Pontilhismo colorido · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `points01`
  Na vida real: no pontilhismo (Seurat) cores puras lado a lado se misturam no olho. Modelo: pontos espalhados com variação de matiz/saturação/valor, grupos mais densos com pressão.

- **`zip.points02`** — Pontilhismo grande · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `points02`
  Na vida real: bolinhas grandes de tinta ficam mais separadas, com sombra de relevo. Modelo: pontos maiores e mais raros, matiz variando, bisel pequeno por carimbo.

- **`zip.points03`** — Granulado de areia · r=24 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `points03`
  Na vida real: grãos de areia/spray muito finos aparecem de forma contínua. Modelo: nuvem densa de grãos minúsculos, opacidade média, nenhum padrão visível por causa da rotação aleatória.

- **`zip.points04`** — Fiapos verticais · r=26 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `points04`
  Na vida real: chuvisco/pelos finos aparecem como pontos esticados na vertical. Modelo: faixa vertical de grãos sempre em pé (sem rotação), vários por passo deslocados, ótimo para fios, pelo ou chuva fina.

- **`zip.sputtering01`** — Respingo grosso · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `sputtering01`
  Na vida real: ao sacudir o pincel, gotas grandes voam na direção do gesto e caem longe; as maiores ficam perto. Modelo: gotas lançadas à frente do traço, maiores e opacas perto, pequenas e fracas longe, esticadas pela velocidade.

- **`zip.sputtering02`** — Respingo fino (névoa) · r=22 · params: Espaçamento, Espalhamento, Densidade, Variação de tamanho · textura: `sputtering02`
  Na vida real: escova de dentes/aerógrafo solta névoa de gotinhas muito pequenas. Modelo: dezenas de gotas pequenas lançadas com ligeiro viés para frente, esticamento por velocidade e queda de opacidade com a distância.


## borracha (27)

- **`borracha.redonda-dura`** — Borracha redonda dura · r=14 · [E]
  Na vida real: uma borracha de vinil nova apaga com borda nitida e limpa, e o tamanho do contato muda com a pressao. Modelo: dab circular de dureza 1 com anti-aliasing de 1px; raio ligado a pressao.

- **`borracha.redonda-macia`** — Borracha redonda macia · r=22 · [E]
  Na vida real: o miolo de uma borracha macia apaga por completo, mas a borda perde forca pouco a pouco porque o contato e menos firme. Modelo: dab gaussiano (dureza 0) sem acumulo de borda: overlaps aprofundam o apagado.

- **`borracha.pressao-opacidade`** — Borracha por pressao · r=16 · [E]
  Na vida real: quanto mais forte voce aperta, mais pigmento sai; leve toque so clareia. Modelo: tamanho fixo; opacidade do apagado vai de 15% a 100% com a pressao.

- **`borracha.translucida-uniforme`** — Borracha translucida 50% · r=18 · [E]
  Na vida real: uma passada de borracha leve remove metade do pigmento, e passar de novo no mesmo ponto na mesma pincelada nao remove mais. Modelo: dabs acumulados em buffer de traco (sem sobreposicao) e compostos uma unica vez a 50%; so uma nova pincelada apaga mais.

- **`borracha.estabilizada`** — Borracha estabilizada · r=12 · [E]
  Na vida real: uma borracha guiada por uma mao firme faz cortes limpos sem tremor. Modelo: suavizacao exponencial da posicao do ponteiro (28px) antes de gerar os dabs.

- **`borracha.varredura`** — Borracha de varredura · r=16 · [E]
  Na vida real: um movimento rapido de braco limpa uma faixa larga; devagar apaga so um fio. Modelo: raio cresce com a velocidade do traco (Speed1) e um pouco com a pressao.

- **`borracha.inclinada`** — Borracha inclinada (tilt) · r=12 · [E]
  Na vida real: inclinar a borracha deita o corpo dela sobre o papel e alonga a area de contato na direcao da inclinacao. Modelo: elipse cujo eixo maior cresce com a declinacao da caneta e aponta para o azimute da inclinacao.

- **`borracha.aerografo`** — Borracha aerografo · r=26 · [E]
  Na vida real: um jato de ar abrasivo remove pigmento aos poucos, mais ainda se voce fica parado. Modelo: dabs gaussianos de baixa opacidade emitidos por tempo (45/s) alem da distancia; hold() continua apagando parado.

- **`borracha.spray-granulado`** — Borracha spray granulado · r=24 · [E] · textura: `air_particle`
  Na vida real: um spray de grao fino respinga particulas; cada gotinha abre um buraquinho isolado. Modelo: mascara air_particle girada ao acaso + dissolve de 55% + jitter, emitida por tempo.

- **`borracha.lapis-vinil`** — Borracha de lapis (vinil) · r=12 · [E] · textura: `flat_rect`
  Na vida real: o vinil retangular tem aresta reta; ela raspa o grafite pela textura do papel e deixa um fantasma claro nos vales. Modelo: mascara flat_rect inclinada 25 graus + grao de papel gating o apagado; pressao empurra o apagado para dentro dos vales.

- **`borracha.maleavel`** — Borracha maleavel (kneaded) · r=20 · [E]
  Na vida real: a massinha cinza levanta o pigmento aos poucos, nunca tira tudo de uma vez; ao pressionar varias vezes, vai clareando. Modelo: opacidade de 14% por dab com acumulo, dureza baixa e grao suave: cada passagem clareia mais.

- **`borracha.borracha-goma`** — Borracha de goma esfarelando · r=16 · [E] · textura: `circle_rough`
  Na vida real: a borracha-goma se desfaz em migalhas ao esfregar, deixando a area apagada irregular. Modelo: mascara circle_rough com rotacao e escala aleatorias, dissolve e jitter de posicao.

- **`borracha.precisao-caneta`** — Borracha de precisao (stick) · r=6 · [E] · textura: `flat_rect`
  Na vida real: a borracha em formato de caneta tem ponta retangular fina para corrigir detalhes pequenos. Modelo: mascara retangular alongada (aspecto 2.8) fixa a 40 graus; raio pequeno.

- **`borracha.eletrica`** — Borracha eletrica · r=8 · [E]
  Na vida real: a borracha eletrica gira e vibra, apagando rapido numa area pequena com cantos irregulares. Modelo: dabs duros de raio pequeno com vibracao aleatoria (jitter 35%) e emissao temporal de 90 dabs/s.

- **`borracha.cinzel-45`** — Borracha cinzel fixa (45 graus) · r=12 · [E] · textura: `flat_rect`
  Na vida real: uma borracha larga e achatada usada de lado apaga faixas retas com aresta diagonal. Modelo: retangulo largo (aspecto 3.5) com angulo fixo de 45 graus, independente da direcao do traco.

- **`borracha.cinzel-direcional`** — Borracha cinzel direcional · r=12 · [E] · textura: `flat_rect`
  Na vida real: ao varrer com a borracha de lado, a aresta fica sempre perpendicular ao movimento. Modelo: retangulo largo que gira para ficar perpendicular a direcao do traco.

- **`borracha.feltro-giz`** — Apagador de feltro (lousa) · r=22 · [E] · textura: `chalk_pastel_soft`
  Na vida real: o apagador de feltro nao limpa a lousa por completo: espalha po de giz e deixa uma nuvem de fibras. Modelo: mascara chalk_pastel_soft girada ao acaso, grao de fibras e dissolve: apaga so parte do giz.

- **`borracha.tinta-abrasiva`** — Borracha de tinta (abrasiva) · r=8 · [E] · textura: `pen_fade`
  Na vida real: a borracha de tinta tem abrasivo que lixa a superficie do papel: o corte e aspero e raspado. Modelo: dab quase duro com grao de papel de alto contraste, dissolve e jitter: borda serrilhada.

- **`borracha.aquarela-clarear`** — Borracha de aquarela (clarear) · r=26 · [E] · textura: `water_bleed`
  Na vida real: tirar aquarela com pano umido levanta o pigmento de forma desigual, com manchas e bordas de flor. Modelo: mascara water_bleed aleatoria com baixa opacidade acumulativa: clareia com bordas organicas.

- **`borracha.carvao-levantar`** — Borracha de carvao (levantar) · r=20 · [E] · textura: `pencil_charcoal`
  Na vida real: para levantar carvao, passa-se a borracha macia em dabs: o po sai pela fibra do papel e deixa reflexos. Modelo: mascara pencil_charcoal orientada pela direcao + grao de fibras, opacidade 40%.

- **`borracha.gaze-tecido`** — Borracha de gaze (esfregar) · r=22 · [E] · textura: `gauze01`
  Na vida real: esfregar com gaze deixa a marca da trama do tecido na area apagada. Modelo: mascara gauze01 girada ao acaso: apaga seguindo a trama.

- **`borracha.tela-trama`** — Borracha de trama de tela · r=16 · [E]
  Na vida real: numa tela de pintura a borracha so alcanca os fios altos da trama; os vales ficam com tinta. Modelo: grao @canvas (trama) com profundidade total: apaga apenas as cristas da trama.

- **`borracha.pastel-esfumada`** — Borracha de pastel (nuvem) · r=24 · [E] · textura: `chalk01`
  Na vida real: o pastel seco sai em nuvens de po quando se esfrega com os dedos ou um chumaco. Modelo: mascara chalk01 aleatoria com 40% de opacidade acumulativa.

- **`borracha.fade`** — Borracha fade (desvanecer) · r=16 · [E]
  Na vida real: uma borracha que perde a forca: no inicio apaga tudo e vai deixando cada vez mais pigmento ate parar de apagar. Modelo: a opacidade cai linearmente de 100% a 0% ao longo de 350px de traco (input Length).

- **`borracha.afilada`** — Borracha afilada (taper) · r=16 · [E]
  Na vida real: uma ponta macia comeca fina, engrossa e termina fina como pincelada. Modelo: raio sobe nos primeiros 40px de traco e depende da pressao no fim.

- **`borracha.pincel-oleo-seco`** — Borracha de pincel oleo · r=18 · [E] · textura: `oil_hair`
  Na vida real: um pincel duro de oleo raspa a tinta e deixa sulcos das cerdas. Modelo: mascara oil_hair orientada pela direcao do traco.

- **`borracha.giz-cera`** — Borracha giz de cera · r=18 · [E] · textura: `chalk_crayon`
  Na vida real: raspar giz de cera com uma unha deixa lascas irregulares. Modelo: mascara chalk_crayon girada ao acaso.


## borracha-especial (39)

- **`borracha.textura-giz-duro`** — Borracha textura giz duro · r=14 · [E] · textura: `chalk_hard`
  Na vida real: uma lixa fina deixa a area com a rugosidade do abrasivo. Modelo: mascara chalk_hard retangular rugosa alinhada ao traco.

- **`borracha.textura-circulo-aspero`** — Borracha circulo aspero · r=16 · [E] · textura: `circle_rough`
  Na vida real: pressionar uma esponja natural deixa um circulo de bordas porosas. Modelo: mascara circle_rough com rotacao aleatoria.

- **`borracha.pontilhada`** — Borracha pontilhada · r=18 · [E] · textura: `points03`
  Na vida real: carimbar com um rolo de espinhos fura o pigmento em milhares de pontos. Modelo: mascara points03 (poeira de pontos) rotacionada ao acaso.

- **`borracha.respingo`** — Borracha de respingos · r=20 · [E] · textura: `sputtering02`
  Na vida real: respingos de solvente comem o pigmento em gotinhas de tamanhos diferentes. Modelo: mascara sputtering02, 2 copias espalhadas por dab com escala aleatoria.

- **`borracha.respingo-grosso`** — Borracha respingo grosso · r=22 · [E] · textura: `sputtering01`
  Na vida real: gotas grandes de agua sanitaria abrem furos redondos isolados. Modelo: mascara sputtering01 (gotas grandes) com 2 copias espalhadas.

- **`borracha.pelo`** — Borracha de pelo · r=22 · [E] · textura: `fur01`
  Na vida real: um pincel seco de pelo arrasta e abre mechas irregulares na tinta. Modelo: mascara fur01 orientada pela direcao e espelhada ao acaso.

- **`borracha.renda`** — Borracha de renda · r=24 · [E] · textura: `net_lace`
  Na vida real: apagar atraves de uma renda como estencil deixa o desenho do bordado vazado. Modelo: mascara net_lace usada como estencil de apagado, alinhada a direcao.

- **`borracha.grade`** — Borracha de grade · r=22 · [E] · textura: `net2`
  Na vida real: apagar por uma tela metalica deixa uma grade quadriculada de furos. Modelo: mascara net2 (grade) com angulo fixo.

- **`borracha.estrela`** — Borracha de estrela · r=14 · [E] · textura: `stamp_star`
  Na vida real: um vazador de papel em forma de estrela corta buracos com o desenho dele. Modelo: mascara stamp_star carimbada com rotacao aleatoria.

- **`borracha.folha`** — Borracha de folha · r=14 · [E] · textura: `stamp_leaf1`
  Na vida real: um vazador em forma de folha deixa buracos com contorno de folha. Modelo: mascara stamp_leaf1 que acompanha a direcao e alterna o espelho.

- **`borracha.coracao`** — Borracha de coracao · r=14 · [E] · textura: `stamp_heart`
  Na vida real: um vazador de coracao abre furos em forma de coracao, sempre em pe. Modelo: mascara stamp_heart sem rotacao.

- **`borracha.floco-de-neve`** — Borracha floco de neve · r=16 · [E] · textura: `stamp_snow1`
  Na vida real: um vazador de floco de neve corta cristais de seis pontas. Modelo: mascara stamp_snow1 com rotacao e escala aleatorias.

- **`borracha.gota`** — Borracha de gota · r=12 · [E] · textura: `stamp_drop`
  Na vida real: gotas de solvente caem e comem a tinta no formato de pingos. Modelo: mascara stamp_drop orientada pela direcao do traco.

- **`borracha.dissolver`** — Borracha dissolver · r=24 · [E]
  Na vida real: um acido fraco corroi uma imagem em pontos aleatorios ate sumir. Modelo: Blend::Dissolve: cada pixel e removido se um ruido hash for menor que a cobertura do dab: derrete em pontilhado.

- **`borracha.halo-bordas`** — Borracha de halo (bordas) · r=24 · [E]
  Na vida real: a franja clara em volta de uma selecao feita com varinha-magica precisa ser tirada sem tocar o miolo. Modelo: Blend::EraseEdge: so apaga pixels semi-transparentes (alpha < limite).

- **`borracha.so-linha`** — Borracha de linha (tinta escura) · r=14 · [E]
  Na vida real: apagar so o contorno preto de um desenho sem estragar as cores e como usar um solvente seletivo. Modelo: Blend::EraseDark: o peso do apagado vem da escuridao do pixel; cores claras sobrevivem.

- **`borracha.so-claro`** — Borracha de areas claras · r=18 · [E]
  Na vida real: remover apenas o branco de um scan sem afetar o desenho escuro. Modelo: Blend::EraseLight: apaga pixels claros (luminancia alta) e preserva os escuros.

- **`borracha.cor-similar`** — Borracha de cor similar (magica) · r=16 · [E] · params: Tolerancia de cor, Dureza da borda
  Na vida real: um corretor que remove so uma cor: toca-se uma vez e ele passa a apagar tudo que se parece com ela. Modelo: amostra a cor sob o primeiro dab e usa Blend::EraseSimilar com tolerancia ajustavel.

- **`borracha.cor-continua`** — Borracha de cor continua · r=16 · [E] · params: Tolerancia de cor, Dureza da borda
  Na vida real: uma borracha que a cada passo olha de novo o que esta sob a ponta e remove cores parecidas com ela. Modelo: reamostra a cor no centro a cada dab e aplica EraseSimilar: acompanha gradientes.

- **`borracha.fundo`** — Borracha de fundo · r=20 · [E] · params: Tolerancia de cor, Dureza da borda
  Na vida real: apagar o fundo de uma foto sem comer o contorno: o centro define o fundo e as linhas escuras sao protegidas. Modelo: reamostra o centro como cor de fundo, ignora amostras escuras ou transparentes e aplica EraseSimilar.

- **`borracha.para-cor-papel`** — Borracha de cor de papel · r=16 · [E] · params: Papel R, Papel G, Papel B
  Na vida real: o corretivo liquido nao remove tinta, cobre com a cor do papel. Modelo: pinta uma cor chapada (parametros R/G/B, padrao branco) em vez de transparencia: ideal para camadas opacas.

- **`borracha.suavizar-bordas`** — Borracha suavizar (feather) · r=18 · [E]
  Na vida real: um pano limpo passado de leve sobre uma borda dura a esfuma. Modelo: Blend::Soften: mistura cada pixel com a media 5x5 local dentro do dab.

- **`borracha.arrastar-apagar`** — Borracha arrasto (smudge-erase) · r=18 · [E]
  Na vida real: esfregar com o dedo puxa a tinta pelo papel e ao mesmo tempo a leva embora. Modelo: arrasta pixels (Smudge de balde longo) e apaga 15% do alpha por dab, entao a mancha vai sumindo.

- **`borracha.halo-sombra`** — Borracha com halo (sombra suave) · r=14 · [E]
  Na vida real: uma ponta apaga o centro por completo e ao redor deixa um anel de sombra que desvanece. Modelo: dois dabs por passo: nucleo duro a 55% do raio + anel gaussiano a 135% com 35% de opacidade.

- **`borracha.simetrica`** — Borracha simetrica (espelho) · r=14 · [E] · params: Eixo de simetria (0-1)
  Na vida real: ao desenhar simetria, cada corte numa metade se repete na outra. Modelo: segundo DabBrush alimentado com a posicao refletida no eixo vertical (parametro eixo).

- **`borracha.regua-protetora`** — Borracha com regua (shield) · r=16 · [E] · params: Angulo da regua (graus), Posicao X da regua (0-1), Posicao Y da regua (0-1)
  Na vida real: o gabarito de metal protege o desenho: a borracha passa por cima e so apaga de um lado da aresta. Modelo: a area apagada e recortada por uma reta (angulo/posicao ajustaveis) com anti-aliasing: o lado onde o traco comecou apaga, o outro e protegido.

- **`borracha.aquarela-lavar`** — Borracha de aquarela (lavar) · r=28 · [E] · params: Tamanho das manchas, Limpeza maxima
  Na vida real: ao lavar a aquarela, a agua leva o pigmento em poças irregulares e nunca deixa o papel perfeitamente limpo. Modelo: campo de ruido fbm com warp: manchas suaves cuja borda e retraida em direcao a borda do dab; limpeza maxima 80%.

- **`borracha.pixel`** — Borracha de pixel (quadrada) · r=8 · [E] · params: Tamanho do pixel
  Na vida real: no pixel art apaga-se pixel a pixel, sem bordas suaves. Modelo: apaga celulas quadradas alinhadas a grade do tamanho de pixel escolhido, sem anti-aliasing.

- **`borracha.cerdas`** — Borracha de cerdas (pincel seco) · r=18 · [E] · params: Numero de cerdas
  Na vida real: um pincel seco embebido em solvente arrasta fios finos paralelos, cada um com carga diferente. Modelo: N linhas de apagado finas, paralelas a direcao, com opacidade e largura individuais moduladas por ruido 1D ao longo do traco.

- **`borracha.riscar`** — Borracha de riscos (lamina) · r=16 · [E] · params: Numero de riscos, Falhas (0-1)
  Na vida real: uma lamina ou agulha raspa linhas finissimas na tinta seca, com falhas quando levanta. Modelo: poucos riscos duros de 1px acompanhando a direcao, com deriva lateral por ruido e interrupcoes.

- **`borracha.regiao-conectada`** — Borracha de regiao (balde de apagar) · r=10 · [E] · params: Tolerancia de cor, Janela maxima (px)
  Na vida real: apagar uma forma inteira de uma vez, como puxar uma pecinha de papel colorido do colagem. Modelo: flood-fill 4-conectado em janela limitada a partir do pixel sob a ponta: apaga a regiao de cor parecida e uma franja de 1px.

- **`borracha.retangulo`** — Borracha retangular · r=10 · [E] · params: Suavidade da borda (px)
  Na vida real: um estilete e uma regua cortam um retangulo perfeito de papel. Modelo: apaga o retangulo definido pelo ponto inicial e final do gesto ao soltar.

- **`borracha.elipse`** — Borracha elipse · r=10 · [E] · params: Suavidade da borda (px)
  Na vida real: um compasso de corte remove um disco ou oval. Modelo: apaga a elipse inscrita no retangulo do gesto, com borda anti-aliased.

- **`borracha.linha-reta`** — Borracha de linha reta · r=10 · [E] · params: Largura da linha, Suavidade da borda (px)
  Na vida real: um estilete numa regua faz um corte reto de uma ponta a outra. Modelo: apaga um capsulo de largura ajustavel entre o primeiro e o ultimo ponto.

- **`borracha.laco`** — Borracha de laco (lasso) · r=10 · [E] · params: Suavidade da borda (px)
  Na vida real: recortar a mao livre com uma tesoura em volta de uma forma. Modelo: o gesto vira um poligono fechado; ao soltar apaga o interior por scanline 4x com cobertura exata.

- **`borracha.tracejada-pontos`** — Borracha pontilhada (pontos) · r=10 · [E]
  Na vida real: uma roda de picotar fura papel em pontos regulares. Modelo: dabs duros espacados 1.6 raios: linha de furos redondos.

- **`borracha.tracejada-traco`** — Borracha tracejada · r=10 · [E]
  Na vida real: um cortador de pizza com serrilha recorta tracos curtos alinhados. Modelo: elipses alongadas orientadas pela direcao com espacamento maior que o comprimento.

- **`borracha.retícula`** — Borracha de reticula (halftone) · r=22 · [E]
  Na vida real: apagar por uma tela de pontos deixa a imagem como impressao de jornal. Modelo: grao @dots (pontos regulares) gating do apagado: sobra uma trama de pontos.

- **`borracha.migalhas`** — Borracha de migalhas · r=14 · [E]
  Na vida real: pedacinhos de borracha esfarelando espalham buracos de tamanhos diferentes. Modelo: 6 dabs por passo espalhados em 1.1 raio com escala variando 90%.


## decor (42)

- **`decor.pontilhada`** — Linha pontilhada · r=4
  Na vida real: pontos de caneta/furos de picote com ritmo constante. Modelo: discos redondos a intervalo fixo em comprimento de arco; raio segue a pressão.

- **`decor.tracejada`** — Linha tracejada · r=3
  Na vida real: tracejado de planta/mapa com traço e vão regulares que seguem a curva. Modelo: traços como trechos da trajetória (não retas), ritmo traço:vão ajustável.

- **`decor.traco-ponto`** — Traço e ponto · r=3
  Na vida real: linha de eixo/centro de desenho técnico (traço longo, vão, ponto, vão). Modelo: período de 4 símbolos sobre o comprimento de arco.

- **`decor.trilho-duplo`** — Linha dupla · r=2
  Na vida real: filete duplo de gráfica/estrada. Modelo: duas trajetórias paralelas deslocadas pela normal local.

- **`decor.trilho-triplo`** — Linha tripla (grossa-fina-grossa) · r=3
  Na vida real: filete de moldura clássico com linha grossa central entre duas finas. Modelo: três trajetórias paralelas de espessuras diferentes.

- **`decor.ondulada`** — Linha ondulada · r=3 · params: Amplitude, Comprimento de onda
  Na vida real: onda senoidal de ornamento/água em desenho. Modelo: deslocamento senoidal da normal em função do arco; amplitude e comprimento de onda são parâmetros.

- **`decor.zigue-zague`** — Dentes / ticks · r=2
  Na vida real: serrilha e marcas de régua. Modelo: riscos perpendiculares alternando comprimento (longo/curto) a intervalo fixo.

- **`decor.corrente`** — Corrente (elos 3D) · r=7
  Na vida real: elos de metal se alternam: um de frente (anel oval) e o seguinte de perfil (barra fina), entrelaçados. Modelo: elos pares = anel elíptico com brilho; ímpares = barra arredondada de perfil; luz superior-esquerda.

- **`decor.corda`** — Corda trançada (3 fios) · r=6 · params: Passo da torção
  Na vida real: três fios torcidos em hélice; cada fio passa na frente e atrás conforme a fase da torção e fica mais claro quando está na frente. Modelo: 3 hélices com fase 120° em função do arco, desenhadas em ordem de profundidade com sombreamento.

- **`decor.arame-farpado`** — Arame farpado · r=3
  Na vida real: dois fios de aço torcidos entre si, com farpas de 4 pontas amarradas a cada ~12 cm. Modelo: dois fios senoidais em contrafase + farpas em X afiadas em intervalo fixo, com brilho metálico.

- **`decor.costura`** — Costura (ponto corrido) · r=3
  Na vida real: linha de pontos de agulha: trechos de fio por cima do tecido com furinhos e pequena sombra nas pontas. Modelo: traços sobre a trajetória com brilho de fio, sombra deslocada e furos escuros nas extremidades.

- **`decor.ponto-cruz`** — Ponto cruz · r=3
  Na vida real: bordado em pontos de cruz, cada ponto são duas diagonais. Modelo: X com fios de brilho diferente (a diagonal superior é mais clara), alinhado ao grid local do traçado.

- **`decor.ziper`** — Zíper · r=4
  Na vida real: dentes metálicos de duas fitas que se encaixam alternados, com o cursor (puxador) no ponto onde fecha. Modelo: dentes retangulares alternados esquerda/direita em meio passo, e puxador desenhado no fim do traço.

- **`decor.fita`** — Fita torcida · r=9
  Na vida real: uma fita de cetim torce ao longo do caminho: mostra o lado de frente, afina quando fica de perfil e revela o verso (outra cor). Modelo: largura = |cos(fase)|; lado frente/verso troca de cor e sombreamento no sinal do cosseno.

- **`decor.renda`** — Barra de renda · r=4
  Na vida real: renda de bordado tem uma linha base e festões (arcos) com olhais (furinhos) no centro de cada arco. Modelo: linha base + semicírculos repetidos + anel e ponto em cada festão.

- **`decor.perolas`** — Fio de pérolas · r=7
  Na vida real: esferas nacaradas enfiadas num fio, com brilho especular e reflexo de borda. Modelo: esfera sombreada (base escura, corpo, brilho e ponto especular) + fio entre elas; pequena variação de tamanho.

- **`decor.gemas`** — Fio de gemas · r=7
  Na vida real: pedras lapidadas refletem a luz em facetas de claridades diferentes. Modelo: hexágono com facetas internas claras/escuras, cor da pedra rotacionada em matiz por pedra.

- **`decor.bandeirinhas`** — Bandeirinhas de festa · r=10
  Na vida real: bandeirolas penduradas num barbante que faz uma curva (catenária) entre dois pontos de fixação. Modelo: curva quadrática com flecha proporcional ao vão entre fixações; triângulos coloridos pendem de cada curva.

- **`decor.luzes-natal`** — Cordão de luzes · r=8
  Na vida real: lâmpadas penduradas num fio com curva, cada uma emitindo halo de luz colorida. Modelo: fio em curva + bulbo (soquete, vidro) + halo aditivo; cor cíclica; brilho oscila com o quadro.

- **`decor.filme`** — Rolo de filme · r=8
  Na vida real: filme 35 mm tem faixas escuras, furos de perfuração nas bordas e quadros claros ao centro. Modelo: faixa escura seguindo a trajetória, furos retangulares claros nos dois lados a passo fixo e divisões de quadro.

- **`decor.trilho-trem`** — Trilho de trem · r=4
  Na vida real: dois trilhos de aço paralelos sobre dormentes de madeira regularmente espaçados. Modelo: dormentes (retângulos de madeira, com variação de tom) e dois trilhos metálicos com brilho.

- **`decor.tijolos`** — Caminho de tijolos · r=9
  Na vida real: tijolos assentados em fiadas com juntas desencontradas (meio tijolo de defasagem) e argamassa clara entre eles. Modelo: duas fiadas de tijolos retangulares com cor variando por tijolo e junta de argamassa.

- **`decor.cerca`** — Cerca de madeira · r=6
  Na vida real: estacas verticais de topo pontudo presas por duas travessas horizontais. Modelo: estacas com alturas ligeiramente irregulares e sombra lateral; travessas contínuas na altura de 30% e 70%.

- **`decor.bambu`** — Bambu · r=6
  Na vida real: colmo cilíndrico verde dividido em gomos por nós salientes; de alguns nós saem ramos com folhas finas. Modelo: tubo sombreado seguindo o traço, anéis nos nós a intervalos e folhas lanceoladas.

- **`decor.meandro-grego`** — Meandro grego · r=3
  Na vida real: friso grego em chave contínua (meandro), geometria ortogonal repetida de ritmo exato. Modelo: padrão de chave em unidades locais ancorado no comprimento de arco, ligado ao próximo módulo.

- **`decor.voluta`** — Voluta / floreio · r=3
  Na vida real: ornamento barroco com espirais (volutas) alternadas dos dois lados do eixo e folhinhas. Modelo: espiral logarítmica a cada passo, lado alternado, com ponto-folha no centro.

- **`decor.seta`** — Seta · r=3
  Na vida real: seta de sinalização com haste e ponta triangular alinhada à última direção do movimento. Modelo: haste desenhada ao longo do traço; ponta calculada no fim a partir da tangente final.

- **`decor.chave-curva`** — Chave { } entre extremos · r=3
  Na vida real: chave agrupa itens: dois quartos de círculo, ponta central e hastes. Modelo: calculada no fim entre início e fim do traço, abre para o lado do arrasto.

- **`decor.hachura`** — Hachura · r=2 · params: Ângulo
  Na vida real: desenhista sombreia com riscos paralelos curtos; mais pressão = traços mais próximos/longos e a mão sempre tremula um pouco. Modelo: riscos num ângulo fixo (45°), comprimento e opacidade por pressão, tremor aleatório controlado.

- **`decor.hachura-cruzada`** — Hachura cruzada · r=2
  Na vida real: ao pressionar mais o artista cruza uma segunda camada de riscos, escurecendo. Modelo: camada 1 sempre; camada 2 (ângulo oposto) só aparece acima de ~45% de pressão; terceira acima de 80%.

- **`decor.hachura-contorno`** — Hachura de contorno · r=2
  Na vida real: hachura que acompanha a forma (curva de nível) para sugerir volume. Modelo: riscos perpendiculares à direção local do traço, levemente curvados para o mesmo lado.

- **`decor.pontilhismo`** — Pontilhismo (estípula) · r=3
  Na vida real: nanquim em pontos; a densidade de pontos cria os tons, e pontos não se sobrepõem muito (distribuição azarada de Poisson). Modelo: N pontos por passo em disco de raio ~2.5r, com N crescendo com a pressão e rejeição de pontos muito próximos dos últimos.

- **`decor.retícula-meio-tom`** — Retícula de meio-tom · r=14 · params: Passo da grade (px)
  Na vida real: impressão offset usa pontos de tamanho variável numa grade rotacionada a 45°; o tom vem da área do ponto. Modelo: grade ancorada na tela (pontos de strokes diferentes alinham), raio do ponto = pressão×falloff do pincel; reaplicar só aumenta o ponto.

- **`decor.areia`** — Granulado de areia · r=12
  Na vida real: grãos minerais de tamanhos e tons ligeiramente diferentes espalhados sem padrão. Modelo: grãos minúsculos aleatórios em disco, tom variando em torno da cor base (claro/escuro).

- **`decor.riscos`** — Riscos e arranhões · r=1
  Na vida real: arranhões em superfície são linhas finas, quase retas, de comprimento aleatório, uns mais claros (expõem o material) e outros escuros. Modelo: riscos longos finos com ligeira curvatura, direção alinhada ao movimento com desvio, tom claro ou escuro.

- **`decor.vidro-quebrado`** — Vidro trincado · r=2
  Na vida real: o impacto cria trincas radiais que partem do ponto e trincas concêntricas poligonais que unem as radiais; algumas radiais se bifurcam. Modelo: 9-14 radiais com comprimento variável e bifurcações, anéis poligonais irregulares ligando raios vizinhos, brilho branco nas arestas.

- **`decor.bolhas-sabao`** — Bolhas de sabão (aglomerado) · r=8
  Na vida real: filme fino de sabão é quase transparente, com contorno irisado e dois reflexos (janela e ponto) em lados opostos. Modelo: disco quase transparente, anel com matiz variando em volta (interferência), brilho principal e reflexo secundário, tamanhos variados.

- **`decor.brilho-glitter`** — Glitter · r=6
  Na vida real: lantejoulas refletem a luz em lampejos pontuais; cada partícula brilha em momento/cor diferente. Modelo: estrelas de 4 pontas de tamanhos variados com matiz aleatório; brilho depende do quadro (cintilação).

- **`decor.confete`** — Confete · r=6
  Na vida real: papelzinhos coloridos giram em 3D ao cair; vistos de lado parecem finos, de frente mostram a área toda. Modelo: retângulos com largura = |cos(rotação 3D)|, cor da paleta, ângulo e fase aleatórios.

- **`decor.estrelas-espalhadas`** — Estrelas espalhadas · r=7
  Na vida real: estrelinhas de 5 pontas de tamanhos diversos como adesivos. Modelo: polígono estrelado regular com rotação aleatória, pequeno brilho e cores quentes.

- **`decor.constelacao`** — Constelação · r=4
  Na vida real: estrelas ligadas por linhas finas formam figuras; as linhas ligam estrelas próximas, não todas. Modelo: estrelas (com brilho) ao longo do traço; cada nova estrela liga-se por fio tênue às 2 anteriores se estiverem a menos de ~9 raios.

- **`decor.rastro-brilhante`** — Rastro de brilho · r=6
  Na vida real: varinha mágica deixa faíscas que flutuam e se apagam; as primeiras ficam e as novas surgem na ponta. Modelo: glints de 4 pontas com deslocamento aleatório da trajetória e tamanho decrescente com o frame de vida.


## manga (14)

- **`manga.linhas-velocidade`** — Linhas de velocidade · r=3
  Na vida real (mangá): traços paralelos à direção do movimento indicam velocidade; ficam finos nas pontas e variam de comprimento. Modelo: 3 linhas afinadas por passo, deslocadas pela normal, comprimento cresce com a velocidade da caneta.

- **`manga.linhas-foco`** — Linhas de concentração · r=3
  Na vida real: linhas radiais convergindo no ponto de foco (choque, surpresa); o centro fica vazio e as linhas variam em espessura. Modelo: ao soltar, ~110 linhas radiais a partir do ponto inicial, vazio central proporcional ao arrasto.

- **`manga.explosao`** — Explosão de impacto · r=3
  Na vida real: balão de impacto com pontas irregulares ao redor de um centro claro. Modelo: ao soltar, polígono estrela de raio alternado aleatório do tamanho do arrasto, preenchimento e contorno.

- **`manga.nuvem-pensamento`** — Balão de pensamento · r=3
  Na vida real: balão de pensamento tem contorno em arcos de nuvem e bolinhas decrescentes levando ao personagem. Modelo: ao soltar, elipse da caixa do traço com festões (arcos) + 3 bolhas decrescentes.

- **`manga.gota-suor`** — Gotas de suor / lágrima · r=6
  Na vida real (convenção do mangá): gotas em forma de lágrima voando do rosto marcam nervosismo. Modelo: a cada passo, gota (ponta + base redonda) lançada em arco para fora, com brilho.

- **`manga.veia-raiva`** — Veia de raiva · r=9
  Na vida real (convenção do mangá): quatro arcos em cruz = veia saltada de irritação. Modelo: no ponto inicial, quatro pares de arcos em L girados 90° com preenchimento vermelho e contorno.

- **`manga.rubor`** — Rubor (hachuras) · r=3
  Na vida real (mangá): rubor nas bochechas é feito por poucas hachuras diagonais, não por cor chapada. Modelo: pequenos feixes de 3 a 4 traços diagonais finos a cada passo, rosados.

- **`manga.linhas-tristeza`** — Linhas de tristeza · r=3
  Na vida real (mangá): faixas verticais caindo sobre o rosto/cenário = depressão, 'cara azul'. Modelo: traços verticais de comprimentos diferentes que descem da linha do traço e afinam.

- **`manga.tom-pontos`** — Retícula (tom de pontos) · r=9
  Na vida real: a retícula/screentone é uma folha de pontos a 45° cuja densidade dá o cinza; pontos maiores = mais escuro. Modelo: grade a 45° fixa na tela (passo ~size*0.55), ponto de raio proporcional à pressão e à distância ao traço.

- **`manga.tom-linhas`** — Retícula de linhas · r=9
  Na vida real: tom de linhas paralelas finas (cinza mecânico). Modelo: linhas a 45° fixas na tela, espaçadas por size*0.5, desenhadas só dentro do raio do pincel.

- **`manga.tom-degrade`** — Retícula em degradê · r=10
  Na vida real: tom degradê (bokashi) = pontos que crescem de forma contínua. Modelo: retícula a 45° em que o raio do ponto varia com a distância percorrida (fino no começo, grosso no fim).

- **`manga.hachura-cruzada`** — Hachura cruzada (kakeami) · r=8
  Na vida real: sombra por cruzamento de hachuras; cada camada de traços em outro ângulo escurece mais. Modelo: dois feixes de traços finos a +45° e -45° com tremor de mão; o segundo só aparece com pressão alta.

- **`manga.balao-fala`** — Balão de fala · r=3
  Na vida real: balão de fala é uma elipse levemente irregular com rabicho apontando ao falante. Modelo: ao soltar, elipse da caixa do traço (preenchida de branco + contorno) e rabicho triangular na direção do último movimento.

- **`manga.vento-redemoinho`** — Redemoinho de vento · r=3
  Na vida real (mangá): vento é desenhado como espirais abertas que terminam em voltinhas. Modelo: a cada passo, curva em espiral logarítmica afinada que sai da trajetória.


## efeitos-anim (14)

- **`efeitos-anim.rastro-movimento`** — Rastro de movimento · r=16
  Na vida real: o obturador aberto grava varios instantes: o objeto deixa um borrão que some atrás. Modelo: ecos translúcidos do disco do pincel espaçados ao longo do caminho, alongados na direção do movimento (smear).

- **`efeitos-anim.fantasma`** — Fantasma (onion ghost) · r=14
  Na vida real (animação): 'eco' translúcido das poses anteriores mostra o arco do movimento. Modelo: discos-anel translúcidos a intervalos regulares, cada vez mais fracos e menores no passado.

- **`efeitos-anim.estrela-impacto`** — Estrela de impacto · r=22
  Na vida real (cartoon): estrela irregular amarela com contorno marca o instante do golpe. Modelo: no ponto inicial, polígono estrela de raios aleatórios que treme a cada frame (frame altera a semente).

- **`efeitos-anim.onda-choque`** — Onda de choque · r=20
  Na vida real: uma explosão/impacto cria uma frente de pressão circular que se expande e enfraquece. Modelo: três anéis elípticos (perspectiva) cujo raio cresce com o número do frame e cuja espessura/alpha caem; use um frame por quadro da animação.

- **`efeitos-anim.poeira-passo`** — Nuvenzinha de poeira · r=11
  Na vida real (animação): ao pisar/frear sobe uma nuvenzinha que incha e some em 4 a 6 quadros. Modelo: aglomerado de 4 a 5 círculos com contorno, tamanho crescente conforme frame, cor creme e miolo mais claro.

- **`efeitos-anim.corte-espada`** — Corte de espada · r=7
  Na vida real (anime): um golpe de espada deixa um arco em meia-lua, afinado nas pontas e quase branco no fio. Modelo: ao soltar, crescente entre início e fim (arco da curvatura do gesto) com núcleo branco e brilho aditivo.

- **`efeitos-anim.linhas-vento`** — Linhas de vento · r=3
  Na vida real (animação): rajada = filetes curvos que terminam numa voltinha. Modelo: fio afinado seguindo o traço com onda lenta e laço no final de cada filete.

- **`efeitos-anim.smear`** — Smear (quadro borrado) · r=20
  Na vida real (animação 2D/sakuga): entre poses extremas o objeto vira um borrão alongado. Modelo: elipse muito esticada na direção do movimento, com opacidade em degradê e bordas multiplicadas.

- **`efeitos-anim.carga-energia`** — Carga de energia · r=6
  Na vida real (anime): partículas de luz convergem ao personagem enquanto ele carrega. Modelo: ao soltar, 60 partículas em raios que vão da periferia ao ponto final, com traços afinando e brilho aditivo mais forte perto do centro.

- **`efeitos-anim.circulo-magico`** — Círculo mágico · r=4
  Na vida real (fantasia): círculo de invocação com anéis concêntricos, polígono inscrito e runas nas bordas, que gira. Modelo: ao soltar, centro = caixa do traço; anéis, hexagrama e marcas de runa, ângulo = frame*3°; brilho aditivo.

- **`efeitos-anim.faiscas-impacto`** — Faíscas de impacto · r=6
  Na vida real: dois materiais se chocando soltam faíscas em raios, mais longas e brancas no centro. Modelo: no ponto inicial, 18 a 26 traços radiais curtos de comprimento aleatório (muda por frame) + flash aditivo e estrela de quatro pontas.

- **`efeitos-anim.brilho`** — Brilho cintilante (shine) · r=10
  Na vida real (animação): brilho de metal/lente aparece como estrela de 4 pontas que pulsa. Modelo: estrelas de quatro pontas ao longo do traço, tamanho pulsa com o frame (fase por estrela), núcleo branco com halo.

- **`efeitos-anim.flash-golpe`** — Flash de golpe · r=12
  Na vida real (cartoon): no instante do impacto a tela 'estoura' em branco com raios. Modelo: no ponto inicial, 12 raios afilados longos e curtos alternados, círculo branco e halo, com pontas que variam por frame.

- **`efeitos-anim.gotas-voando`** — Gotas voando · r=5
  Na vida real: gotas lançadas descrevem parábolas (movimento balístico). Modelo: no ponto inicial, 7 gotas com velocidades iniciais aleatórias e a posição do frame calculada pela parábola; cada frame avança no tempo.


## pixel (7)

- **`pixel.caneta`** — Caneta pixel · r=2
  Na vida real (pixel art): cada pixel é um quadrado de cor chapada na grade; linhas são escadas sem suavização. Modelo: o traço é amostrado a cada 1 px e cada amostra pinta um bloco alinhado à grade (sem antialiasing).

- **`pixel.dither-bayer2`** — Dither Bayer 2x2 · r=8
  Na vida real (pixel art clássico): dither ordenado simula tons com 5 níveis usando matriz 2x2. Modelo: pixel só é pintado onde o limiar da matriz < densidade (pressão); padrão fixo na tela.

- **`pixel.dither-bayer4`** — Dither Bayer 4x4 · r=8
  Na vida real: matriz de Bayer 4x4 dá 17 níveis de cinza com textura em cruzeta fina. Modelo: limiar ordenado 4x4 ancorado na tela.

- **`pixel.dither-bayer8`** — Dither Bayer 8x8 · r=8
  Na vida real: Bayer 8x8 dá degradê quase contínuo (65 níveis) com padrão discreto. Modelo: limiar 8x8 gerado recursivamente.

- **`pixel.dither-xadrez`** — Dither xadrez · r=8
  Na vida real: meio-tom 50% em tabuleiro, usado em consoles antigos para simular transparência. Modelo: pinta pixels com (x+y) par.

- **`pixel.dither-linhas`** — Dither de linhas · r=8
  Na vida real: linhas horizontais alternadas (televisão/CRT) como cinza 50%. Modelo: pinta linhas y par.

- **`pixel.sombra-luz`** — Luz e sombra pixel · r=3
  Na vida real (pixel art): sombreamento por rampa de cores, luz no canto superior esquerdo e sombra no inferior direito, em blocos. Modelo: cada bloco clareia (Overlay) no topo-esquerda e escurece embaixo-direita, sem suavização.
